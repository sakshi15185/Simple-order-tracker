"""Unit tests for input validation logic and defensive boundaries."""

from src.validator import (
    validate_order_id,
    validate_customer_name,
    validate_phone,
    validate_email,
    validate_item_name,
    validate_quantity,
    validate_unit_price,
    validate_discount_pct,
    validate_delivery_fee,
    validate_date_str,
)


def test_validate_order_id():
    valid, val = validate_order_id("ORD-2026-1001")
    assert valid is True
    assert val == "ORD-2026-1001"

    valid, _ = validate_order_id("ord_99")
    assert valid is True

    valid, err = validate_order_id("   ")
    assert valid is False
    assert "cannot be blank" in err

    valid, err = validate_order_id("ORD@#!?")
    assert valid is False
    assert "alphanumeric" in err


def test_validate_customer_name():
    valid, val = validate_customer_name("john doe")
    assert valid is True
    assert val == "John Doe"

    valid, val = validate_customer_name("Dr. Jane O'Connor-Smith")
    assert valid is True

    valid, err = validate_customer_name("")
    assert valid is False

    valid, err = validate_customer_name("A")
    assert valid is False
    assert "at least 2 characters" in err

    valid, err = validate_customer_name("User1234")
    assert valid is False


def test_validate_phone():
    valid, val = validate_phone("+1 555-0199")
    assert valid is True

    valid, val = validate_phone("+91 98765-43210")
    assert valid is True

    valid, err = validate_phone("123")
    assert valid is False
    assert "between 7 and 15 digits" in err

    valid, err = validate_phone("letters-only")
    assert valid is False


def test_validate_email():
    valid, val = validate_email("user@example.com")
    assert valid is True
    assert val == "user@example.com"

    valid, val = validate_email("alice.smith+tag@sub.domain.org")
    assert valid is True

    valid, err = validate_email("notanemail")
    assert valid is False

    valid, err = validate_email("user@domain")
    assert valid is False


def test_validate_quantity():
    assert validate_quantity(1)[0] is True
    assert validate_quantity("5")[0] is True
    assert validate_quantity("5")[1] == 5

    assert validate_quantity(0)[0] is False
    assert validate_quantity(-1)[0] is False
    assert validate_quantity("abc")[0] is False


def test_validate_unit_price():
    assert validate_unit_price(19.99)[0] is True
    assert validate_unit_price("15.50")[0] is True
    assert validate_unit_price("15.50")[1] == 15.50

    assert validate_unit_price(0.0)[0] is False
    assert validate_unit_price(-10.0)[0] is False
    assert validate_unit_price("free")[0] is False


def test_validate_discount_pct():
    assert validate_discount_pct(0.0)[0] is True
    assert validate_discount_pct(50.0)[0] is True
    assert validate_discount_pct(100.0)[0] is True

    assert validate_discount_pct(-1.0)[0] is False
    assert validate_discount_pct(105.0)[0] is False
    assert validate_discount_pct("half")[0] is False


def test_validate_delivery_fee():
    assert validate_delivery_fee(0.0)[0] is True
    assert validate_delivery_fee(10.50)[0] is True

    assert validate_delivery_fee(-5.0)[0] is False
    assert validate_delivery_fee("none")[0] is False


def test_validate_date_str():
    assert validate_date_str("2026-11-18")[0] is True
    assert validate_date_str("18-11-2026")[0] is False
    assert validate_date_str("2026/11/18")[0] is False
