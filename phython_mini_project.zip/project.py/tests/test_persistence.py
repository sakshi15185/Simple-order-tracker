"""Unit tests for local file persistence, atomic writing, and corruption recovery."""

import json
from pathlib import Path

from src.models import Order, OrderItem
from src.config import OrderStatus
from src.persistence import PersistenceManager


def test_persistence_save_and_load(tmp_path: Path):
    json_file = tmp_path / "orders.json"
    csv_file = tmp_path / "orders.csv"
    pm = PersistenceManager(json_path=json_file, csv_path=csv_file)

    # Initial empty state
    orders, warnings = pm.load_orders()
    assert orders == []
    assert warnings == []

    # Save an order
    order = Order(
        order_id="ORD-PERSIST-1",
        customer_name="Alice Persist",
        customer_phone="+1 555-0100",
        customer_email="alice@persist.com",
        items=[OrderItem(name="Item 1", quantity=2, unit_price=10.0)],
    )
    pm.save_orders([order])

    # Verify JSON file exists and has content
    assert json_file.exists()
    assert csv_file.exists()

    # Load back
    loaded_orders, load_warnings = pm.load_orders()
    assert len(loaded_orders) == 1
    assert loaded_orders[0].order_id == "ORD-PERSIST-1"
    assert loaded_orders[0].customer_name == "Alice Persist"
    assert loaded_orders[0].total_amount == 21.00  # 20 + 5% tax (1.0) = 21.00


def test_persistence_corrupted_json_recovery(tmp_path: Path):
    json_file = tmp_path / "corrupt_orders.json"
    csv_file = tmp_path / "corrupt_orders.csv"

    # Write corrupted raw bytes
    with open(json_file, "w", encoding="utf-8") as f:
        f.write("{ this is clearly broken json }")

    pm = PersistenceManager(json_path=json_file, csv_path=csv_file)
    orders, warnings = pm.load_orders()

    # Should not crash! Must return empty orders list and log warning
    assert orders == []
    assert len(warnings) == 1
    assert "Corrupted JSON detected" in warnings[0]

    # Verify corrupted backup was created
    bak_files = list(tmp_path.glob("*.bak"))
    assert len(bak_files) >= 1

    # Verify json_file was reset to valid empty array
    with open(json_file, "r", encoding="utf-8") as f:
        data = json.load(f)
        assert data == []
