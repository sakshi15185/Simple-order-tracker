"""Unit tests for legacy CSV dataset bulk ingestion and validation error reporting."""

from pathlib import Path

from src.bulk_importer import BulkImporter
from src.config import OrderStatus


def test_bulk_importer_valid_and_invalid_rows(tmp_path: Path):
    csv_file = tmp_path / "legacy.csv"
    csv_content = (
        "order_id,customer_name,phone,email,items,discount_pct,delivery_fee,status,payment_status\n"
        "LEG-001,Valid Alice,+1 555-0101,alice@leg.com,Coffee:2:15.00,5.0,3.00,PLACED,PENDING\n"
        "BAD_ID_%,Valid Bob,+1 555-0102,bob@leg.com,Tea:1:10.00,0.0,0.00,PLACED,PENDING\n"
        "LEG-003,,+1 555-0103,charlie@leg.com,Bread:1:8.00,0.0,0.00,PLACED,PENDING\n"
        "LEG-004,Valid Dan,+1 555-0104,dan@leg.com,Scone:2:4.00,0.0,2.00,INVALID_STATUS,PENDING\n"
    )
    csv_file.write_text(csv_content, encoding="utf-8")

    result = BulkImporter.import_csv(csv_file)
    assert result.total_rows == 4
    assert result.successful_count == 1
    assert result.error_count == 3
    assert len(result.imported_orders) == 1
    assert result.imported_orders[0].order_id == "LEG-001"
    assert result.imported_orders[0].customer_name == "Valid Alice"
    assert len(result.errors) == 3
    assert Path(result.log_file).exists()
