"""Unit tests for executive summary KPIs and aggregations."""

from src.models import Order, OrderItem
from src.config import OrderStatus, PaymentStatus
from src.analytics import OrderAnalytics


def test_order_analytics_empty():
    analytics = OrderAnalytics([])
    kpis = analytics.get_summary_kpis()
    assert kpis["total_orders"] == 0
    assert kpis["total_revenue"] == 0.0
    status_df = analytics.get_status_distribution()
    assert len(status_df) == len(OrderStatus)


def test_order_analytics_with_data():
    o1 = Order(
        order_id="ORD-A1",
        customer_name="Customer 1",
        customer_phone="+1 555-0101",
        customer_email="c1@example.com",
        items=[OrderItem(name="Croissant", quantity=2, unit_price=5.0)],  # 10.0 + 5% = 10.50
        status=OrderStatus.DELIVERED,
        payment_status=PaymentStatus.PAID,
    )
    o2 = Order(
        order_id="ORD-A2",
        customer_name="Customer 2",
        customer_phone="+1 555-0102",
        customer_email="c2@example.com",
        items=[OrderItem(name="Coffee Beans", quantity=1, unit_price=20.0)],  # 20.0 + 5% = 21.00
        status=OrderStatus.PLACED,
        payment_status=PaymentStatus.PENDING,
    )

    analytics = OrderAnalytics([o1, o2])
    kpis = analytics.get_summary_kpis()

    assert kpis["total_orders"] == 2
    assert kpis["total_revenue"] == 31.50
    assert kpis["paid_revenue"] == 10.50
    assert kpis["pending_revenue"] == 21.00
    assert kpis["total_items_sold"] == 3

    # Top products
    top_prods = analytics.get_top_products(5)
    assert len(top_prods) == 2
    assert "Coffee Beans" in top_prods["Product"].values
