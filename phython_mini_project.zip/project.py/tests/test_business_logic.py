"""Unit tests for the central OrderManager business logic."""

from pathlib import Path

from src.models import Order, OrderItem
from src.config import OrderStatus, PaymentStatus
from src.persistence import PersistenceManager
from src.business_logic import OrderManager


def setup_test_manager(tmp_path: Path) -> OrderManager:
    json_path = tmp_path / "orders.json"
    csv_path = tmp_path / "orders.csv"
    pm = PersistenceManager(json_path, csv_path)
    return OrderManager(persistence=pm)


def test_create_and_get_order(tmp_path: Path):
    mgr = setup_test_manager(tmp_path)
    assert mgr.count() == 0

    order = Order(
        order_id="ORD-2026-0001",
        customer_name="John Doe",
        customer_phone="+1 555-0100",
        customer_email="john@doe.com",
        items=[OrderItem(name="Coffee", quantity=1, unit_price=10.0)],
    )
    ok, msg = mgr.create_order(order)
    assert ok is True
    assert mgr.count() == 1

    # Duplicate rejection
    ok_dup, msg_dup = mgr.create_order(order)
    assert ok_dup is False
    assert "already exists" in msg_dup

    # Retrieval
    retrieved = mgr.get_order("ord-2026-0001")  # Case-insensitive
    assert retrieved is not None
    assert retrieved.customer_name == "John Doe"


def test_update_status_and_payment(tmp_path: Path):
    mgr = setup_test_manager(tmp_path)
    order = Order(
        order_id="ORD-2026-0002",
        customer_name="Jane Smith",
        customer_phone="+1 555-0100",
        customer_email="jane@smith.com",
        items=[OrderItem(name="Tea", quantity=2, unit_price=8.0)],
    )
    mgr.create_order(order)

    # Valid status update
    ok, msg = mgr.update_order_status("ORD-2026-0002", OrderStatus.PROCESSING, note="Preparing tea")
    assert ok is True
    assert mgr.get_order("ORD-2026-0002").status == OrderStatus.PROCESSING

    # Payment update
    ok, msg = mgr.update_payment_status("ORD-2026-0002", PaymentStatus.PAID)
    assert ok is True
    assert mgr.get_order("ORD-2026-0002").payment_status == PaymentStatus.PAID


def test_search_and_filter_orders(tmp_path: Path):
    mgr = setup_test_manager(tmp_path)
    o1 = Order(
        order_id="ORD-01",
        customer_name="Alice Coffee",
        customer_phone="+1 555-1111",
        customer_email="alice@coffee.com",
        items=[OrderItem(name="Cappuccino", quantity=1, unit_price=15.0)],
        status=OrderStatus.PLACED,
        payment_status=PaymentStatus.PENDING,
    )
    o2 = Order(
        order_id="ORD-02",
        customer_name="Bob Tea",
        customer_phone="+1 555-2222",
        customer_email="bob@tea.com",
        items=[OrderItem(name="Green Tea", quantity=2, unit_price=20.0)],
        status=OrderStatus.DELIVERED,
        payment_status=PaymentStatus.PAID,
    )
    mgr.create_order(o1)
    mgr.create_order(o2)

    # Keyword search
    res = mgr.search_orders(keyword="cappuccino")
    assert len(res) == 1
    assert res[0].order_id == "ORD-01"

    # Status filter
    res_deliv = mgr.search_orders(status=OrderStatus.DELIVERED)
    assert len(res_deliv) == 1
    assert res_deliv[0].order_id == "ORD-02"

    # Payment status filter
    res_paid = mgr.search_orders(payment_status=PaymentStatus.PAID)
    assert len(res_paid) == 1
    assert res_paid[0].order_id == "ORD-02"
