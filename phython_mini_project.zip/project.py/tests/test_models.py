"""Unit tests for models, dataclasses, calculations, and state machine transitions."""

import pytest
from datetime import datetime, timezone, timedelta

from src.models import OrderItem, Order, StatusHistoryEntry
from src.config import OrderStatus, PaymentStatus, PaymentMethod


def test_order_item_valid():
    item = OrderItem(name="Artisan Coffee Beans", quantity=3, unit_price=15.50)
    assert item.name == "Artisan Coffee Beans"
    assert item.quantity == 3
    assert item.unit_price == 15.50
    assert item.subtotal == 46.50
    assert item.to_dict() == {
        "name": "Artisan Coffee Beans",
        "quantity": 3,
        "unit_price": 15.50,
        "subtotal": 46.50,
    }


def test_order_item_invalid():
    with pytest.raises(ValueError, match="Item name cannot be empty"):
        OrderItem(name="   ", quantity=1, unit_price=10.0)

    with pytest.raises(ValueError, match="Quantity must be a positive integer"):
        OrderItem(name="Coffee", quantity=0, unit_price=10.0)

    with pytest.raises(ValueError, match="Quantity must be a positive integer"):
        OrderItem(name="Coffee", quantity=-2, unit_price=10.0)

    with pytest.raises(ValueError, match="Unit price must be greater than zero"):
        OrderItem(name="Coffee", quantity=1, unit_price=0.0)

    with pytest.raises(ValueError, match="Unit price must be greater than zero"):
        OrderItem(name="Coffee", quantity=1, unit_price=-5.0)


def test_order_calculations():
    items = [
        OrderItem(name="Item A", quantity=2, unit_price=50.00),  # 100.00
        OrderItem(name="Item B", quantity=1, unit_price=20.00),  # 20.00
    ]
    # Subtotal = 120.00
    # Discount 10% = 12.00
    # Taxable = 108.00
    # Tax 5% = 5.40
    # Delivery = 5.00
    # Grand Total = 108.00 + 5.40 + 5.00 = 118.40
    order = Order(
        order_id="ORD-TEST-001",
        customer_name="Alice Smith",
        customer_phone="+1 555-0199",
        customer_email="alice@example.com",
        items=items,
        discount_pct=10.0,
        delivery_fee=5.00,
        tax_rate=0.05,
    )

    assert order.total_quantity == 3
    assert order.subtotal == 120.00
    assert order.discount_amount == 12.00
    assert order.taxable_amount == 108.00
    assert order.tax_amount == 5.40
    assert order.total_amount == 118.40
    assert order.status == OrderStatus.PLACED


def test_order_state_machine_valid_flow():
    items = [OrderItem(name="Item A", quantity=1, unit_price=25.00)]
    order = Order(
        order_id="ORD-FSM-001",
        customer_name="Bob Miller",
        customer_phone="+1 555-0123",
        customer_email="bob@example.com",
        items=items,
    )
    assert order.status == OrderStatus.PLACED
    assert len(order.status_history) == 1

    # PLACED -> PROCESSING
    assert order.can_transition_to(OrderStatus.PROCESSING)
    order.transition_to(OrderStatus.PROCESSING, note="In kitchen")
    assert order.status == OrderStatus.PROCESSING
    assert len(order.status_history) == 2

    # PROCESSING -> SHIPPED
    assert order.can_transition_to(OrderStatus.SHIPPED)
    order.transition_to(OrderStatus.SHIPPED, note="Out for delivery")
    assert order.status == OrderStatus.SHIPPED
    assert len(order.status_history) == 3

    # SHIPPED -> DELIVERED
    assert order.can_transition_to(OrderStatus.DELIVERED)
    order.transition_to(OrderStatus.DELIVERED, note="Delivered to porch")
    assert order.status == OrderStatus.DELIVERED
    assert len(order.status_history) == 4

    # Terminal state: cannot transition further
    assert not order.can_transition_to(OrderStatus.PLACED)
    assert not order.can_transition_to(OrderStatus.CANCELLED)
    with pytest.raises(ValueError, match="Invalid transition"):
        order.transition_to(OrderStatus.PLACED)


def test_order_state_machine_illegal_skips():
    items = [OrderItem(name="Item A", quantity=1, unit_price=25.00)]
    order = Order(
        order_id="ORD-FSM-002",
        customer_name="Bob Miller",
        customer_phone="+1 555-0123",
        customer_email="bob@example.com",
        items=items,
    )

    # Cannot skip directly to DELIVERED
    with pytest.raises(ValueError, match="Invalid transition from 'PLACED' to 'DELIVERED'"):
        order.transition_to(OrderStatus.DELIVERED)

    # Cannot transition to same status
    with pytest.raises(ValueError, match="already in status 'PLACED'"):
        order.transition_to(OrderStatus.PLACED)


def test_order_cancellation_flow():
    items = [OrderItem(name="Item A", quantity=1, unit_price=25.00)]
    order = Order(
        order_id="ORD-FSM-003",
        customer_name="Charlie Brown",
        customer_phone="+1 555-0123",
        customer_email="charlie@example.com",
        items=items,
    )
    # Cancel from PLACED
    order.transition_to(OrderStatus.CANCELLED, note="Customer changed mind")
    assert order.status == OrderStatus.CANCELLED

    # Terminal state check
    with pytest.raises(ValueError, match="Invalid transition"):
        order.transition_to(OrderStatus.PROCESSING)


def test_order_overdue_check():
    items = [OrderItem(name="Item A", quantity=1, unit_price=25.00)]
    now = datetime.now(timezone.utc)
    old_time = (now - timedelta(hours=50)).isoformat()

    order = Order(
        order_id="ORD-OVERDUE-01",
        customer_name="Diana Prince",
        customer_phone="+1 555-0123",
        customer_email="diana@example.com",
        items=items,
        created_at=old_time,
        status=OrderStatus.PLACED,
    )
    assert order.is_overdue(hours_threshold=48) is True

    # Fresh order not overdue
    fresh_order = Order(
        order_id="ORD-FRESH-01",
        customer_name="Diana Prince",
        customer_phone="+1 555-0123",
        customer_email="diana@example.com",
        items=items,
        created_at=now.isoformat(),
        status=OrderStatus.PLACED,
    )
    assert fresh_order.is_overdue(hours_threshold=48) is False
