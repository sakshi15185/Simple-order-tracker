# Simple Order Tracker 🛒📦
### SmartCommunity Hack — Project #85 | Domain: Small Business & Retail
> **A resilient, lightweight, zero-overhead order recording and lifecycle tracking system with defensive input validation, atomic dual-file persistence (JSON/CSV), state-machine status flows, executive analytics, and interactive Terminal & Tkinter GUI interfaces.**

---

## 1. Problem Context & Objectives
Small retail businesses, specialty cafes, craft shops, and local enterprises frequently struggle with recording orders and updating statuses manually or across disconnected spreadsheets. These manual workflows suffer from:
- **Calculation errors**: Manual tax, discounts, and line-item totals leading to cash imbalances.
- **Misplaced records**: Fragile spreadsheets with no atomic write safeguards or lifecycle history.
- **Delayed status insights**: Lack of SLA threshold tracking resulting in overdue, forgotten orders.
- **Heavyweight alternatives**: Enterprise ERPs that demand steep learning curves, expensive monthly subscriptions, and complex server setups.

**Simple Order Tracker** provides a focused, accessible Python utility engineered to streamline data handling, strictly validate entries, guarantee local persistence, and present actionable executive intelligence.

---

## 2. System Architecture

```text
c:\Users\bheem\OneDrive\Desktop\project.py\
├── main.py                     # Primary launcher (CLI menu, --gui, --demo, --export, --summary)
├── demo.py                     # Scripted end-to-end hackathon demonstration
├── requirements.txt            # Python dependencies (pandas, matplotlib, pytest)
├── README.md                   # Mentor guide and technical documentation
│
├── src/                        # Modular Core Engine
│   ├── config.py               # Constants, file paths, business rules, ANSI colors
│   ├── models.py               # Dataclasses: OrderItem, Order, OrderStatus, FSM transitions
│   ├── validator.py            # Centralized crash-proof input wrappers and regex checks
│   ├── persistence.py          # Atomic JSON & CSV storage, schema validation, backup recovery
│   ├── business_logic.py       # OrderManager: CRUD, state machine enforcement, query engine
│   ├── analytics.py            # Vectorized Pandas KPIs, status breakdown, top products
│   ├── exporter.py             # Multi-format exports: Markdown, CSV, TXT audit, Matplotlib PNG
│   ├── bulk_importer.py        # Legacy CSV dataset parser with row-by-row error logging
│   ├── cli.py                  # Interactive ANSI terminal console with paginated tables
│   └── gui.py                  # Tkinter Graphical User Interface
│
├── data/                       # Local File Persistence
│   ├── orders.json             # Active JSON database
│   ├── orders.csv              # Active CSV mirror for spreadsheets
│   ├── sample_orders.json      # 42 realistic pre-seeded retail records
│   └── legacy_import_sample.csv# Legacy CSV dataset with valid & invalid test rows
│
├── reports/                    # Generated Outputs & Audit Trails
│   ├── executive_summary.md    # Markdown executive report with KPI cards
│   ├── sales_summary.csv       # Aggregated status & financial metrics
│   ├── orders_export.csv       # Flat CSV export of all orders
│   ├── orders_analytics.png    # 4-panel Matplotlib visual analytics dashboard
│   ├── audit_log.txt           # Continuous operational timestamped audit trail
│   └── import_log_*.txt        # Row-by-row legacy CSV import validation logs
│
└── tests/                      # Automated Test Suite (Pytest)
    ├── test_models.py          # Unit tests for calculations, state machine, overdue checks
    ├── test_validator.py       # Boundary and regex validation tests
    ├── test_persistence.py     # Atomic save/load and corrupted JSON recovery tests
    ├── test_business_logic.py  # OrderManager search, filter, and CRUD tests
    ├── test_analytics.py       # KPI computations and aggregations tests
    └── test_bulk_importer.py   # Legacy CSV ingestion and error logging tests
```

---

## 3. Core Features (Must-Have)

| Feature | Technical Implementation |
| :--- | :--- |
| **Interactive Terminal Interface** | ANSI-colored menus, breadcrumb navigation, and fixed-width paginated tables (e.g. 8 records/page with `[N]ext`, `[P]rev`, `[V]iew Details`, `[U]pdate Status`). |
| **Defensive Input Validation** | Centralized input wrappers with regex for Order ID (`^[A-Za-z0-9\-_]{3,25}$`), customer name, phone (`7-15 digits`), email format, quantity (`>= 1`), unit price (`> $0.00`), and discount (`0-100%`). |
| **Finite State Machine (FSM)** | Strict order lifecycle progression: `PLACED` $\rightarrow$ `PROCESSING` $\rightarrow$ `SHIPPED` $\rightarrow$ `DELIVERED`. Illegal transitions (e.g. `PLACED` directly to `DELIVERED` or transitioning a `CANCELLED` order) are strictly rejected with clear error messages. |
| **Financial Computation Engine** | Automatic computation of subtotal, percentage discounts, 5% tax, delivery fees, and grand totals with floating-point rounding safeguards. |
| **Local Data Persistence** | Atomic dual-file storage: JSON maintains nested line items and transition histories; CSV mirror is automatically kept in sync for external spreadsheets. Auto-creates directories and recovers from corrupted files with automatic `.bak` backups. |
| **Multi-Criteria Search & Filter** | Instant querying across keywords (Order ID, customer, phone, email, product items), status filters, payment status filters, and amount/date ranges. |
| **Executive Business Summary** | Pandas and NumPy-powered vectorized KPI generation: gross revenue, average order value (AOV), fulfillment rate, and top-selling products. |

---

## 4. Stretch Features (Good-to-Have)

1. **Multi-Format Summary Export**:
   - `reports/executive_summary.md`: Formatted Markdown report with KPI tables and warning alerts.
   - `reports/sales_summary.csv` & `reports/orders_export.csv`: Standard CSV tables for spreadsheet tools.
   - `reports/orders_analytics.png`: High-resolution 4-panel visual dashboard generated via Matplotlib (status donut chart, revenue by status bar chart, top products, payment breakdown).
   - `reports/audit_log.txt`: Plain-text timestamped audit trail recording every state change and order creation.
2. **Threshold Warning Indicators**:
   - **48-Hour SLA Overdue Monitor**: Automatically detects and flags active orders remaining in `PLACED` or `PROCESSING` past 48 hours without dispatch.
   - **High-Value Alerts**: Visual flags highlighting orders $\ge \$500.00$.
   - **Unpaid Dispatched Alerts**: Warns when orders in `SHIPPED` or `DELIVERED` state have pending payments.
3. **Interactive Graphical User Interface (Tkinter GUI)**:
   - Clean, zero-external-dependency GUI with search bar, status dropdowns, interactive data table, order creation dialog, status transition modals, and one-click export actions.
4. **Bulk Dataset CSV Ingestion**:
   - Ingests legacy CSV datasets with row-by-row validation, flexible header mapping, and automatic generation of error audit logs detailing invalid rows.

---

## 5. Quickstart & Installation

### Requirements
- Python 3.10+ (tested on Python 3.14)
- Standard library dependencies + `pandas`, `matplotlib`, `pytest`

### Setup
```bash
# Clone or navigate to the project directory
cd "c:\Users\bheem\OneDrive\Desktop\project.py"

# Install dependencies
pip install -r requirements.txt
```

### Running the Application
```bash
# 1. Interactive ANSI Terminal Interface
python main.py

# 2. Lightweight Graphical User Interface (Tkinter GUI)
python main.py --gui

# 3. Automated Hackathon Demonstration Journey
python main.py --demo
# or
python demo.py

# 4. Instant Terminal KPI Dashboard
python main.py --summary

# 5. Headless Report & Chart Generation
python main.py --export

# 6. Reset / Reseed the 42 Realistic Sample Records
python main.py --seed
```

---

## 6. What a Good Demo Looks Like (Hackathon Walkthrough)

To deliver an outstanding demo for the SmartCommunity Hackathon judges, run:
```bash
python main.py --demo
```
The automated script executes the following 8-step journey:
1. **Launch & Storage State Assessment**: Confirms existing 42 small-business retail records loaded from `data/orders.json` and `data/orders.csv`.
2. **Defensive Input Validation in Action**: Intentionally feeds malformed inputs (invalid characters, blank names, negative unit prices, discount > 100%) and proves how the validator safely intercepts every error without crashing. Then records a valid order `ORD-2026-DEMO`.
3. **Core Business Logic & FSM Life Cycle**: Attempts an illegal skip (`PLACED` directly to `DELIVERED`) to showcase state machine validation; then progresses through `PLACED` $\rightarrow$ `PROCESSING` $\rightarrow$ `SHIPPED` $\rightarrow$ `DELIVERED` with audit notes.
4. **Threshold Warning Indicators**: Surfaces orders exceeding the 48-hour SLA deadline and highlights high-value orders $\ge \$500.00$.
5. **Executive Summary & Analytics**: Computes real-time KPIs (Total Revenue, Paid Revenue, AOV, Fulfillment Rate, and Top-Selling Products).
6. **Multi-Format Export**: Generates Markdown, CSVs, and the Matplotlib dashboard image (`orders_analytics.png`).
7. **Bulk Legacy CSV Ingestion**: Ingests `data/legacy_import_sample.csv`, proving row-by-row error auditing (validating 4 clean rows, flagging 3 corrupted rows with line numbers and reasons).
8. **Persistence Verification (Cold Restart)**: Simulates a complete application restart to verify that `ORD-2026-DEMO` and all state transitions are 100% preserved.

---

## 7. Automated Test Suite

The test suite covers models, state transitions, regex boundaries, file persistence, corruption recovery, and analytics:

```bash
pytest -v
```

### Test Coverage Highlights:
- `test_models.py`: Verifies `OrderItem` boundaries, floating-point financial computations (subtotal, discounts, tax, delivery fee), and legal vs illegal state transitions (`PLACED` $\rightarrow$ `PROCESSING` $\rightarrow$ `SHIPPED` $\rightarrow$ `DELIVERED`).
- `test_validator.py`: Tests regex rules for Order IDs, customer names, phone numbers, emails, unit prices, and date formats.
- `test_persistence.py`: Verifies atomic file writing and **auto-recovery from corrupted JSON** (backing up `.corrupt.bak` and re-initializing safely).
- `test_business_logic.py`: Tests duplicate rejection, search/filter queries, and audit logging.
- `test_analytics.py`: Tests Pandas-powered aggregation metrics and top-product rankings.
- `test_bulk_importer.py`: Tests legacy CSV parsing and error audit logging.

---

## 8. Sample Dataset

The project includes **42 realistic small business & retail records** (`data/sample_orders.json` and `data/orders.csv`) modeling everyday retail domains:
- Specialty Coffee Roasters & Bakery
- Boutique Bookstores & Stationery
- Artisan Ceramics & Home Decor
- Eco-Friendly Wellness & Apothecary
- Technical & Culinary Tools

Test cases include normal retail orders, boundary tests (0% discount, $0 delivery fee, 50% promotional campaign), multi-item orders (up to 5 line items), overdue orders (>48h pending), cancelled orders with audit notes, and high-value orders ($500 - $700+).

---

## 9. License & Credits
Developed for **SmartCommunity Hack — Project #85: Simple Order Tracker**.  
Standard MIT License. Built with Python 3, Pandas, and Matplotlib.
