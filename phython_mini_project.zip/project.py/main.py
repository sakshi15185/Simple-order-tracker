"""
Simple Order Tracker - Main Application Entry Point
SmartCommunity Hack #85 | Small Business & Retail Operations

Usage:
    python main.py                # Interactive ANSI Terminal Interface
    python main.py --gui          # Graphical User Interface (Tkinter)
    python main.py --demo         # Automated Hackathon Showcase Journey
    python main.py --export       # Headless Report & Chart Generation
    python main.py --summary      # Instant Terminal KPI Dashboard
"""

import sys
import argparse
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).resolve().parent))

from src.business_logic import OrderManager
from src.cli import CommandLineInterface
from src.analytics import OrderAnalytics
from src.exporter import ReportExporter
from src.config import Colors


def parse_arguments():
    parser = argparse.ArgumentParser(
        description="Simple Order Tracker - High-Reliability Small Business Order Management"
    )
    parser.add_argument(
        "--gui", "-g", action="store_true", help="Launch Graphical User Interface (Tkinter)"
    )
    parser.add_argument(
        "--demo", "-d", action="store_true", help="Run automated end-to-end hackathon demonstration"
    )
    parser.add_argument(
        "--export", "-e", action="store_true", help="Generate all reports (Markdown, CSV, PNG chart) headlessly"
    )
    parser.add_argument(
        "--summary", "-s", action="store_true", help="Print executive KPI summary and exit"
    )
    parser.add_argument(
        "--seed", action="store_true", help="Seed/reset 42 sample records and exit"
    )
    return parser.parse_args()


def main():
    args = parse_arguments()
    manager = OrderManager()

    if args.seed:
        from src.seed_data import generate_sample_data
        generate_sample_data()
        print(f"{Colors.GREEN}Sample dataset seeded successfully.{Colors.RESET}")
        return

    if args.gui:
        try:
            from src.gui import launch_gui
            launch_gui(manager)
        except Exception as e:
            print(f"{Colors.RED}[!] Could not launch GUI: {e}{Colors.RESET}")
        return

    if args.demo:
        from demo import run_demo
        run_demo(manager)
        return

    if args.export:
        analytics = OrderAnalytics(manager.get_all_orders())
        exporter = ReportExporter(analytics)
        md = exporter.export_markdown_report()
        sum_csv, ord_csv = exporter.export_csv_reports()
        chart = exporter.export_chart()
        print(f"{Colors.GREEN}✓ Reports successfully exported:{Colors.RESET}")
        print(f"  - Markdown: {md}")
        print(f"  - Sales CSV: {sum_csv}")
        print(f"  - Orders CSV: {ord_csv}")
        if chart:
            print(f"  - Chart PNG: {chart}")
        return

    if args.summary:
        analytics = OrderAnalytics(manager.get_all_orders())
        kpis = analytics.get_summary_kpis()
        status_df = analytics.get_status_distribution()
        print(f"\n{Colors.CYAN}{Colors.BOLD}=== SIMPLE ORDER TRACKER SUMMARY ==={Colors.RESET}")
        print(f"Total Orders:          {kpis['total_orders']}")
        print(f"Total Gross Revenue:   ${kpis['total_revenue']:,.2f}")
        print(f"Paid Revenue:          ${kpis['paid_revenue']:,.2f}")
        print(f"Pending Receivables:   ${kpis['pending_revenue']:,.2f}")
        print(f"Average Order Value:   ${kpis['avg_order_value']:,.2f}")
        print(f"Total Items Sold:      {kpis['total_items_sold']} units")
        print(f"Overdue SLA Orders:    {kpis['overdue_orders_count']}")
        print(f"\nFulfillment Status Breakdown:")
        print(status_df.to_string(index=False))
        return

    # Default: Interactive Terminal Interface
    cli = CommandLineInterface(manager)
    cli.run()


if __name__ == "__main__":
    main()
