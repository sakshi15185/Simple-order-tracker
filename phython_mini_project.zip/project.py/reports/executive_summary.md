# Simple Order Tracker - Executive Business Report
**Generated:** 2026-11-18 10:06:24 UTC  
**Domain:** Small Business & Retail | SmartCommunity Hack #85  

---

## 1. Executive Key Performance Indicators (KPIs)

| Metric | Value |
| :--- | :--- |
| **Total Orders Logged** | 43 |
| **Total Gross Revenue** | $6,093.31 |
| **Collected / Paid Revenue** | $5,312.80 |
| **Pending Receivables** | $436.61 |
| **Average Order Value (AOV)** | $141.70 |
| **Total Line Items Sold** | 153 units |
| **Discounts Applied** | $367.30 |
| **Tax Collected (5%)** | $278.61 |
| **Fulfillment Completion Rate** | 50.0% |
| **Average Fulfillment SLA** | 35.5 hours |
| **Overdue Orders Alert** | 3 order(s) |
| **High-Value Orders (>$500)** | 3 order(s) |

---

## 2. Order Status Distribution

| Status | Count | Share (%) | Revenue ($) |
| :--- | :---: | :---: | :---: |
| **PLACED** | 6 | 14.0% | $532.22 |
| **PROCESSING** | 8 | 18.6% | $776.06 |
| **SHIPPED** | 6 | 14.0% | $1,399.06 |
| **DELIVERED** | 20 | 46.5% | $3,042.07 |
| **CANCELLED** | 3 | 7.0% | $343.90 |

---

## 3. Payment Status Breakdown

| Payment Status | Count | Revenue ($) |
| :--- | :---: | :---: |
| **PENDING** | 5 | $436.61 |
| **PAID** | 35 | $5,312.80 |
| **REFUNDED** | 3 | $343.90 |

---

## 4. Top 5 Best-Selling Products

| Product Description | Quantity Sold | Total Revenue ($) |
| :--- | :---: | :---: |
| Specialty Nitro Cold Brew System | 1 | $620.00 |
| Smart Espresso Grinder Pro | 1 | $550.00 |
| Handmade Stoneware Dinner Set (16pc) | 1 | $380.00 |
| Cashmere Travel Wrap | 1 | $240.00 |
| Professional Chef Knife (8in) | 1 | $185.00 |

---

## 5. Top 5 Customers by Spend

| Customer Name | Orders Placed | Total Spent ($) |
| :--- | :---: | :---: |
| James Henderson | 1 | $723.19 |
| Natasha Romanoff | 1 | $676.00 |
| Sophia Vance | 1 | $515.85 |
| Rachel Green | 1 | $268.20 |
| Monica Geller | 1 | $226.43 |

---

## 6. Threshold Warnings & Operational Flags

> [!WARNING] **3 Overdue Order(s) Exceeding 48h SLA:**
- **ORD-2026-1005** | Customer: Priya Sharma | Status: PROCESSING | Created: 2026-11-15
- **ORD-2026-1004** | Customer: David K. Miller | Status: PLACED | Created: 2026-11-14
- **ORD-2026-1020** | Customer: Arthur Dent | Status: PLACED | Created: 2026-11-13

> [!IMPORTANT] **3 High-Value Order(s) (>= $500.00):**
- **ORD-2026-1010** | Customer: James Henderson | Total: $723.19 | Status: SHIPPED
- **ORD-2026-1003** | Customer: Sophia Vance | Total: $515.85 | Status: DELIVERED
- **ORD-2026-1019** | Customer: Natasha Romanoff | Total: $676.00 | Status: DELIVERED
