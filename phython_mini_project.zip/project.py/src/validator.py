"""
Centralized Input Validation and Safe Interactive Prompting
Provides sanitization, boundary checks, regular expressions, and crash-proof input wrappers.
"""

import re
from typing import Callable, Optional, Tuple, Any, List
from src.config import Colors


# --- Regular Expressions ---
ORDER_ID_REGEX = re.compile(r"^[A-Za-z0-9\-_]{3,25}$")
NAME_REGEX = re.compile(r"^[A-Za-z\s\.\'\-]{2,60}$")
PHONE_REGEX = re.compile(r"^\+?[0-9\s\-\(\)]{7,20}$")
EMAIL_REGEX = re.compile(r"^[\w\.\-\+]+@[\w\-]+(\.[\w\-]+)+$")
DATE_REGEX = re.compile(r"^\d{4}-\d{2}-\d{2}$")


# --- Pure Validation Functions ---

def validate_order_id(value: str) -> Tuple[bool, str]:
    """Validates alphanumeric order ID (e.g., ORD-2026-001)."""
    val = value.strip().upper()
    if not val:
        return False, "Order ID cannot be blank."
    if not ORDER_ID_REGEX.match(val):
        return False, "Order ID must be 3-25 alphanumeric characters (hyphens and underscores allowed)."
    return True, val


def validate_customer_name(value: str) -> Tuple[bool, str]:
    """Sanitizes and validates customer name."""
    val = " ".join(value.strip().split())  # Normalize internal spaces
    if not val:
        return False, "Customer name cannot be blank."
    if len(val) < 2:
        return False, "Customer name must be at least 2 characters long."
    if len(val) > 60:
        return False, "Customer name cannot exceed 60 characters."
    if not NAME_REGEX.match(val):
        return False, "Customer name contains invalid characters. Use letters, spaces, hyphens, or periods."
    return True, val.title()


def validate_phone(value: str) -> Tuple[bool, str]:
    """Validates contact phone number."""
    val = value.strip()
    if not val:
        return False, "Phone number cannot be blank."
    digits_only = re.sub(r"\D", "", val)
    if len(digits_only) < 7 or len(digits_only) > 15:
        return False, "Phone number must contain between 7 and 15 digits."
    if not PHONE_REGEX.match(val):
        return False, "Invalid phone format. Please provide a standard 7-15 digit phone number."
    return True, val


def validate_email(value: str) -> Tuple[bool, str]:
    """Validates email format."""
    val = value.strip().lower()
    if not val:
        return False, "Email address cannot be blank."
    if not EMAIL_REGEX.match(val):
        return False, "Invalid email format. Example: customer@example.com"
    return True, val


def validate_item_name(value: str) -> Tuple[bool, str]:
    """Validates item description."""
    val = value.strip()
    if not val:
        return False, "Item name cannot be blank."
    if len(val) < 2:
        return False, "Item name must be at least 2 characters."
    if len(val) > 80:
        return False, "Item name cannot exceed 80 characters."
    return True, val


def validate_quantity(value: Any) -> Tuple[bool, Any]:
    """Ensures quantity is a positive integer >= 1."""
    try:
        val = int(value)
        if val < 1:
            return False, "Quantity must be at least 1."
        if val > 100_000:
            return False, "Quantity cannot exceed 100,000 units."
        return True, val
    except (ValueError, TypeError):
        return False, "Quantity must be a valid whole number (e.g., 1, 2, 5)."


def validate_unit_price(value: Any) -> Tuple[bool, Any]:
    """Ensures unit price is a positive float."""
    try:
        val = float(value)
        if val <= 0.0:
            return False, "Unit price must be strictly greater than $0.00."
        if val > 1_000_000.0:
            return False, "Unit price exceeds maximum threshold ($1,000,000)."
        return True, round(val, 2)
    except (ValueError, TypeError):
        return False, "Unit price must be a valid monetary number (e.g., 19.99)."


def validate_discount_pct(value: Any) -> Tuple[bool, Any]:
    """Ensures discount percentage is between 0% and 100%."""
    try:
        val = float(value)
        if val < 0.0 or val > 100.0:
            return False, "Discount must be between 0.0% and 100.0%."
        return True, round(val, 2)
    except (ValueError, TypeError):
        return False, "Discount percentage must be a valid number (e.g., 0, 10, 15.5)."


def validate_delivery_fee(value: Any) -> Tuple[bool, Any]:
    """Ensures delivery fee is non-negative."""
    try:
        val = float(value)
        if val < 0.0:
            return False, "Delivery fee cannot be negative."
        if val > 10_000.0:
            return False, "Delivery fee exceeds maximum threshold ($10,000)."
        return True, round(val, 2)
    except (ValueError, TypeError):
        return False, "Delivery fee must be a valid positive number or 0."


def validate_date_str(value: str) -> Tuple[bool, str]:
    """Validates date format YYYY-MM-DD."""
    val = value.strip()
    if not DATE_REGEX.match(val):
        return False, "Date must follow YYYY-MM-DD format (e.g., 2026-11-18)."
    return True, val


# --- Safe Interactive Terminal Prompt Wrappers ---

def prompt_string(
    prompt_label: str,
    validator_func: Optional[Callable[[str], Tuple[bool, Any]]] = None,
    default: Optional[str] = None,
    allow_cancel: bool = True,
) -> Optional[str]:
    """
    Safely prompts user for string input, looping until valid or user cancels with ':q'.
    """
    default_hint = f" [{default}]" if default is not None else ""
    cancel_hint = " (type ':q' to cancel)" if allow_cancel else ""

    while True:
        try:
            raw = input(f"{Colors.BOLD}{prompt_label}{default_hint}{cancel_hint}: {Colors.RESET}").strip()
            if allow_cancel and raw.lower() == ":q":
                print(f"{Colors.YELLOW}Operation cancelled.{Colors.RESET}")
                return None

            if not raw and default is not None:
                raw = default

            if validator_func:
                is_valid, result = validator_func(raw)
                if not is_valid:
                    print(f"{Colors.RED}  [!] Validation Error: {result}{Colors.RESET}")
                    continue
                return result
            else:
                if not raw:
                    print(f"{Colors.RED}  [!] Input cannot be empty.{Colors.RESET}")
                    continue
                return raw
        except (KeyboardInterrupt, EOFError):
            print(f"\n{Colors.YELLOW}Input interrupted. Returning to menu...{Colors.RESET}")
            return None


def prompt_int(
    prompt_label: str,
    min_val: int = 1,
    max_val: Optional[int] = None,
    default: Optional[int] = None,
    allow_cancel: bool = True,
) -> Optional[int]:
    """Safely prompts user for an integer within [min_val, max_val]."""
    def _validator(val_str: str):
        try:
            val = int(val_str)
            if val < min_val:
                return False, f"Value must be at least {min_val}."
            if max_val is not None and val > max_val:
                return False, f"Value cannot exceed {max_val}."
            return True, val
        except ValueError:
            return False, "Please enter a valid whole number."

    default_str = str(default) if default is not None else None
    res = prompt_string(prompt_label, _validator, default=default_str, allow_cancel=allow_cancel)
    return res if res is not None else None


def prompt_float(
    prompt_label: str,
    min_val: float = 0.0,
    max_val: Optional[float] = None,
    default: Optional[float] = None,
    allow_cancel: bool = True,
) -> Optional[float]:
    """Safely prompts user for a floating-point number within [min_val, max_val]."""
    def _validator(val_str: str):
        try:
            val = float(val_str)
            if val < min_val:
                return False, f"Value must be at least {min_val}."
            if max_val is not None and val > max_val:
                return False, f"Value cannot exceed {max_val}."
            return True, round(val, 2)
        except ValueError:
            return False, "Please enter a valid numeric value."

    default_str = str(default) if default is not None else None
    res = prompt_string(prompt_label, _validator, default=default_str, allow_cancel=allow_cancel)
    return res if res is not None else None


def prompt_choice(
    prompt_label: str,
    choices: List[str],
    default: Optional[str] = None,
    allow_cancel: bool = True,
) -> Optional[str]:
    """Presents a numbered list of choices and returns the selected item string."""
    print(f"{Colors.CYAN}{prompt_label}:{Colors.RESET}")
    for idx, choice in enumerate(choices, 1):
        def_tag = " (default)" if choice == default else ""
        print(f"  [{idx}] {choice}{def_tag}")

    while True:
        try:
            cancel_hint = " or ':q' to cancel" if allow_cancel else ""
            raw = input(f"{Colors.BOLD}Select [1-{len(choices)}]{cancel_hint}: {Colors.RESET}").strip()
            if allow_cancel and raw.lower() == ":q":
                print(f"{Colors.YELLOW}Selection cancelled.{Colors.RESET}")
                return None

            if not raw and default is not None:
                return default

            if raw.isdigit():
                idx = int(raw)
                if 1 <= idx <= len(choices):
                    return choices[idx - 1]

            print(f"{Colors.RED}  [!] Please select a number between 1 and {len(choices)}.{Colors.RESET}")
        except (KeyboardInterrupt, EOFError):
            print(f"\n{Colors.YELLOW}Selection interrupted.{Colors.RESET}")
            return None


def prompt_confirm(prompt_label: str, default: bool = True) -> bool:
    """Prompts user for (y/n) confirmation."""
    hint = "[Y/n]" if default else "[y/N]"
    try:
        raw = input(f"{Colors.BOLD}{prompt_label} {hint}: {Colors.RESET}").strip().lower()
        if not raw:
            return default
        return raw in ("y", "yes", "true", "1")
    except (KeyboardInterrupt, EOFError):
        return False
