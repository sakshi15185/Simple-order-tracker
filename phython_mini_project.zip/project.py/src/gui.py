"""
Lightweight Graphical User Interface (Tkinter)
Provides visual table navigation, order creation wizard, status transition modals,
KPI dashboard widgets, and one-click report exports.
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from datetime import datetime, timezone
from typing import Optional, List

from src.models import Order, OrderItem
from src.config import (
    OrderStatus,
    PaymentStatus,
    PaymentMethod,
    ALLOWED_TRANSITIONS,
    HIGH_VALUE_THRESHOLD,
    DEFAULT_TAX_RATE,
)
from src.business_logic import OrderManager
from src.validator import (
    validate_order_id,
    validate_customer_name,
    validate_phone,
    validate_email,
)
from src.analytics import OrderAnalytics
from src.exporter import ReportExporter
from src.bulk_importer import BulkImporter


class OrderTrackerGUI:
    """Tkinter-based Graphical User Interface for Simple Order Tracker."""

    def __init__(self, root: tk.Tk, manager: OrderManager):
        self.root = root
        self.manager = manager
        self.root.title("Simple Order Tracker - SmartCommunity Hack #85")
        self.root.geometry("1150x700")
        self.root.minsize(950, 600)

        # Apply clean theme
        style = ttk.Style()
        style.theme_use("clam")

        self._build_ui()
        self.refresh_table()

    def _build_ui(self):
        # 1. Top Header & KPI Summary
        header_frame = ttk.Frame(self.root, padding="10 10 10 5")
        header_frame.pack(fill=tk.X)

        title_lbl = ttk.Label(
            header_frame,
            text="Simple Order Tracker | Small Business & Retail",
            font=("Segoe UI", 16, "bold"),
            foreground="#1E3A8A"
        )
        title_lbl.pack(anchor=tk.W)

        self.kpi_frame = ttk.Frame(self.root, padding="10 5 10 5")
        self.kpi_frame.pack(fill=tk.X)

        self.kpi_labels = {}
        for metric in ["Total Orders", "Gross Revenue", "Paid Revenue", "Overdue Alert"]:
            sub = ttk.LabelFrame(self.kpi_frame, text=metric, padding="5 5 5 5")
            sub.pack(side=tk.LEFT, expand=True, fill=tk.BOTH, padx=4)
            lbl = ttk.Label(sub, text="-", font=("Segoe UI", 13, "bold"), foreground="#1F2937")
            lbl.pack(anchor=tk.CENTER)
            self.kpi_labels[metric] = lbl

        # 2. Filter Bar
        filter_frame = ttk.LabelFrame(self.root, text="Search & Filter", padding="10 5 10 5")
        filter_frame.pack(fill=tk.X, padx=10, pady=5)

        ttk.Label(filter_frame, text="Keyword:").pack(side=tk.LEFT, padx=(0, 4))
        self.search_var = tk.StringVar()
        self.search_entry = ttk.Entry(filter_frame, textvariable=self.search_var, width=18)
        self.search_entry.pack(side=tk.LEFT, padx=(0, 10))
        self.search_entry.bind("<Return>", lambda e: self.apply_filters())

        ttk.Label(filter_frame, text="Status:").pack(side=tk.LEFT, padx=(0, 4))
        self.status_var = tk.StringVar(value="ALL")
        status_opts = ["ALL"] + [s.value for s in OrderStatus]
        self.status_cb = ttk.Combobox(filter_frame, textvariable=self.status_var, values=status_opts, state="readonly", width=12)
        self.status_cb.pack(side=tk.LEFT, padx=(0, 10))

        ttk.Label(filter_frame, text="Payment:").pack(side=tk.LEFT, padx=(0, 4))
        self.pay_var = tk.StringVar(value="ALL")
        pay_opts = ["ALL"] + [p.value for p in PaymentStatus]
        self.pay_cb = ttk.Combobox(filter_frame, textvariable=self.pay_var, values=pay_opts, state="readonly", width=12)
        self.pay_cb.pack(side=tk.LEFT, padx=(0, 10))

        ttk.Button(filter_frame, text="Filter", command=self.apply_filters).pack(side=tk.LEFT, padx=4)
        ttk.Button(filter_frame, text="Reset", command=self.reset_filters).pack(side=tk.LEFT, padx=4)

        # 3. Main Orders Table
        table_frame = ttk.Frame(self.root, padding="10 0 10 5")
        table_frame.pack(fill=tk.BOTH, expand=True)

        columns = ("id", "customer", "phone", "total", "status", "payment", "method", "created")
        self.tree = ttk.Treeview(table_frame, columns=columns, show="headings", selectmode="browse")

        self.tree.heading("id", text="Order ID")
        self.tree.heading("customer", text="Customer Name")
        self.tree.heading("phone", text="Phone")
        self.tree.heading("total", text="Total ($)")
        self.tree.heading("status", text="Order Status")
        self.tree.heading("payment", text="Payment Status")
        self.tree.heading("method", text="Method")
        self.tree.heading("created", text="Created (UTC)")

        self.tree.column("id", width=110, anchor=tk.W)
        self.tree.column("customer", width=160, anchor=tk.W)
        self.tree.column("phone", width=120, anchor=tk.W)
        self.tree.column("total", width=90, anchor=tk.E)
        self.tree.column("status", width=100, anchor=tk.CENTER)
        self.tree.column("payment", width=100, anchor=tk.CENTER)
        self.tree.column("method", width=100, anchor=tk.CENTER)
        self.tree.column("created", width=140, anchor=tk.W)

        # Scrollbars
        vsb = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=self.tree.yview)
        hsb = ttk.Scrollbar(table_frame, orient=tk.HORIZONTAL, command=self.tree.xview)
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)

        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        vsb.pack(side=tk.RIGHT, fill=tk.Y)
        self.tree.bind("<Double-1>", lambda e: self.view_order_details())

        # 4. Action Buttons Toolbar
        action_frame = ttk.Frame(self.root, padding="10 8 10 10")
        action_frame.pack(fill=tk.X)

        ttk.Button(action_frame, text="✚ New Order", command=self.open_new_order_dialog).pack(side=tk.LEFT, padx=3)
        ttk.Button(action_frame, text="➜ Update Status", command=self.open_update_status_dialog).pack(side=tk.LEFT, padx=3)
        ttk.Button(action_frame, text="💳 Update Payment", command=self.open_update_payment_dialog).pack(side=tk.LEFT, padx=3)
        ttk.Button(action_frame, text="👁 View Details", command=self.view_order_details).pack(side=tk.LEFT, padx=3)
        ttk.Button(action_frame, text="📊 Analytics", command=self.show_analytics_dialog).pack(side=tk.LEFT, padx=3)
        ttk.Button(action_frame, text="📥 Bulk Import", command=self.bulk_import_csv).pack(side=tk.LEFT, padx=3)
        ttk.Button(action_frame, text="📤 Export Reports", command=self.export_all_reports).pack(side=tk.LEFT, padx=3)
        ttk.Button(action_frame, text="⟳ Reload Sample", command=self.reload_sample_data).pack(side=tk.RIGHT, padx=3)

    def refresh_kpis(self):
        analytics = OrderAnalytics(self.manager.get_all_orders())
        kpis = analytics.get_summary_kpis()
        self.kpi_labels["Total Orders"].config(text=str(kpis["total_orders"]))
        self.kpi_labels["Gross Revenue"].config(text=f"${kpis['total_revenue']:,.2f}")
        self.kpi_labels["Paid Revenue"].config(text=f"${kpis['paid_revenue']:,.2f}")

        overdue_cnt = kpis["overdue_orders_count"]
        if overdue_cnt > 0:
            self.kpi_labels["Overdue Alert"].config(text=f"{overdue_cnt} Overdue!", foreground="#DC2626")
        else:
            self.kpi_labels["Overdue Alert"].config(text="None (All On Track)", foreground="#16A34A")

    def refresh_table(self, orders: Optional[List[Order]] = None):
        if orders is None:
            orders = self.manager.get_all_orders()

        # Clear existing
        for item in self.tree.get_children():
            self.tree.delete(item)

        for o in orders:
            self.tree.insert("", tk.END, values=(
                o.order_id,
                o.customer_name,
                o.customer_phone,
                f"${o.total_amount:.2f}",
                o.status.value,
                o.payment_status.value,
                o.payment_method.value,
                o.created_at[:19].replace("T", " "),
            ))

        self.refresh_kpis()

    def apply_filters(self):
        kw = self.search_var.get().strip() or None
        st_val = self.status_var.get()
        st = OrderStatus(st_val) if st_val != "ALL" else None
        pay_val = self.pay_var.get()
        pay = PaymentStatus(pay_val) if pay_val != "ALL" else None

        filtered = self.manager.search_orders(keyword=kw, status=st, payment_status=pay)
        self.refresh_table(filtered)

    def reset_filters(self):
        self.search_var.set("")
        self.status_var.set("ALL")
        self.pay_var.set("ALL")
        self.refresh_table()

    def _get_selected_order(self) -> Optional[Order]:
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("Selection Required", "Please select an order from the table first.")
            return None
        values = self.tree.item(selected[0], "values")
        order_id = values[0]
        order = self.manager.get_order(order_id)
        if not order:
            messagebox.showerror("Error", f"Order '{order_id}' could not be found.")
            return None
        return order

    def view_order_details(self):
        order = self._get_selected_order()
        if not order:
            return

        win = tk.Toplevel(self.root)
        win.title(f"Order Details - {order.order_id}")
        win.geometry("600x620")

        txt = tk.Text(win, wrap=tk.WORD, font=("Consolas", 10), padx=10, pady=10)
        txt.pack(fill=tk.BOTH, expand=True)

        lines = [
            f"ORDER DETAILS: {order.order_id}",
            "=" * 50,
            f"Customer Name:   {order.customer_name}",
            f"Contact Phone:   {order.customer_phone}",
            f"Email Address:   {order.customer_email}",
            f"Order Status:    {order.status.value}",
            f"Payment Status:  {order.payment_status.value} ({order.payment_method.value})",
            f"Created At:      {order.created_at[:19].replace('T', ' ')} UTC",
            f"Last Updated:    {order.updated_at[:19].replace('T', ' ')} UTC",
            "",
            "LINE ITEMS BREAKDOWN:",
            "-" * 50,
        ]
        for idx, it in enumerate(order.items, 1):
            lines.append(f"{idx}. {it.name:<30} x{it.quantity} @ ${it.unit_price:.2f} = ${it.subtotal:.2f}")

        lines.extend([
            "-" * 50,
            f"Subtotal:             ${order.subtotal:.2f}",
            f"Discount ({order.discount_pct}%):       -${order.discount_amount:.2f}",
            f"Tax (5%):             +${order.tax_amount:.2f}",
            f"Delivery Fee:         +${order.delivery_fee:.2f}",
            f"GRAND TOTAL:          ${order.total_amount:.2f}",
            "",
            f"Notes: {order.notes or 'None'}",
            "",
            "LIFECYCLE AUDIT TRAIL:",
            "-" * 50,
        ])
        for idx, h in enumerate(order.status_history, 1):
            ts = h.timestamp[:19].replace("T", " ")
            lines.append(f"[{ts}] -> {h.status} | {h.note}")

        txt.insert(tk.END, "\n".join(lines))
        txt.configure(state="disabled")

    def open_update_status_dialog(self):
        order = self._get_selected_order()
        if not order:
            return

        allowed = ALLOWED_TRANSITIONS.get(order.status, [])
        if not allowed:
            messagebox.showinfo("Terminal State", f"Order {order.order_id} is in '{order.status.value}' and cannot transition further.")
            return

        dlg = tk.Toplevel(self.root)
        dlg.title(f"Update Status - {order.order_id}")
        dlg.geometry("400x260")
        dlg.grab_set()

        ttk.Label(dlg, text=f"Order: {order.order_id}", font=("Segoe UI", 11, "bold")).pack(pady=(15, 2))
        ttk.Label(dlg, text=f"Current Status: {order.status.value}").pack(pady=2)

        ttk.Label(dlg, text="Select Next Status:").pack(pady=(10, 2))
        target_var = tk.StringVar(value=allowed[0].value)
        cb = ttk.Combobox(dlg, textvariable=target_var, values=[s.value for s in allowed], state="readonly", width=18)
        cb.pack(pady=4)

        ttk.Label(dlg, text="Transition Note / Audit Comment:").pack(pady=(8, 2))
        note_entry = ttk.Entry(dlg, width=35)
        note_entry.pack(pady=4)

        def _do_update():
            target_status = OrderStatus(target_var.get())
            note = note_entry.get().strip()
            ok, msg = self.manager.update_order_status(order.order_id, target_status, note=note)
            if ok:
                messagebox.showinfo("Success", msg)
                dlg.destroy()
                self.refresh_table()
            else:
                messagebox.showerror("Error", msg)

        ttk.Button(dlg, text="Confirm Transition", command=_do_update).pack(pady=15)

    def open_update_payment_dialog(self):
        order = self._get_selected_order()
        if not order:
            return

        dlg = tk.Toplevel(self.root)
        dlg.title(f"Update Payment - {order.order_id}")
        dlg.geometry("380x220")
        dlg.grab_set()

        ttk.Label(dlg, text=f"Order: {order.order_id}", font=("Segoe UI", 11, "bold")).pack(pady=(15, 2))
        ttk.Label(dlg, text=f"Current Payment: {order.payment_status.value}").pack(pady=2)

        ttk.Label(dlg, text="New Payment Status:").pack(pady=(10, 2))
        p_var = tk.StringVar(value=order.payment_status.value)
        cb = ttk.Combobox(dlg, textvariable=p_var, values=[p.value for p in PaymentStatus], state="readonly", width=18)
        cb.pack(pady=4)

        def _do_pay_update():
            new_p = PaymentStatus(p_var.get())
            ok, msg = self.manager.update_payment_status(order.order_id, new_p)
            if ok:
                messagebox.showinfo("Success", msg)
                dlg.destroy()
                self.refresh_table()
            else:
                messagebox.showerror("Error", msg)

        ttk.Button(dlg, text="Update Payment Status", command=_do_pay_update).pack(pady=15)

    def open_new_order_dialog(self):
        dlg = tk.Toplevel(self.root)
        dlg.title("Record New Order")
        dlg.geometry("520x640")
        dlg.grab_set()

        frame = ttk.Frame(dlg, padding="15 15 15 15")
        frame.pack(fill=tk.BOTH, expand=True)

        next_id = self.manager.generate_next_order_id()
        ttk.Label(frame, text="Order ID:").grid(row=0, column=0, sticky=tk.W, pady=3)
        id_entry = ttk.Entry(frame, width=30)
        id_entry.insert(0, next_id)
        id_entry.grid(row=0, column=1, sticky=tk.W, pady=3)

        ttk.Label(frame, text="Customer Name:").grid(row=1, column=0, sticky=tk.W, pady=3)
        name_entry = ttk.Entry(frame, width=30)
        name_entry.grid(row=1, column=1, sticky=tk.W, pady=3)

        ttk.Label(frame, text="Phone:").grid(row=2, column=0, sticky=tk.W, pady=3)
        phone_entry = ttk.Entry(frame, width=30)
        phone_entry.insert(0, "+1 555-0100")
        phone_entry.grid(row=2, column=1, sticky=tk.W, pady=3)

        ttk.Label(frame, text="Email:").grid(row=3, column=0, sticky=tk.W, pady=3)
        email_entry = ttk.Entry(frame, width=30)
        email_entry.insert(0, "customer@example.com")
        email_entry.grid(row=3, column=1, sticky=tk.W, pady=3)

        ttk.Separator(frame, orient=tk.HORIZONTAL).grid(row=4, column=0, columnspan=2, sticky=tk.EW, pady=8)

        ttk.Label(frame, text="Item Name:").grid(row=5, column=0, sticky=tk.W, pady=3)
        item_entry = ttk.Entry(frame, width=30)
        item_entry.grid(row=5, column=1, sticky=tk.W, pady=3)

        ttk.Label(frame, text="Quantity:").grid(row=6, column=0, sticky=tk.W, pady=3)
        qty_entry = ttk.Entry(frame, width=15)
        qty_entry.insert(0, "1")
        qty_entry.grid(row=6, column=1, sticky=tk.W, pady=3)

        ttk.Label(frame, text="Unit Price ($):").grid(row=7, column=0, sticky=tk.W, pady=3)
        price_entry = ttk.Entry(frame, width=15)
        price_entry.insert(0, "19.99")
        price_entry.grid(row=7, column=1, sticky=tk.W, pady=3)

        ttk.Separator(frame, orient=tk.HORIZONTAL).grid(row=8, column=0, columnspan=2, sticky=tk.EW, pady=8)

        ttk.Label(frame, text="Discount (%):").grid(row=9, column=0, sticky=tk.W, pady=3)
        disc_entry = ttk.Entry(frame, width=15)
        disc_entry.insert(0, "0.0")
        disc_entry.grid(row=9, column=1, sticky=tk.W, pady=3)

        ttk.Label(frame, text="Delivery Fee ($):").grid(row=10, column=0, sticky=tk.W, pady=3)
        deliv_entry = ttk.Entry(frame, width=15)
        deliv_entry.insert(0, "0.0")
        deliv_entry.grid(row=10, column=1, sticky=tk.W, pady=3)

        ttk.Label(frame, text="Payment Method:").grid(row=11, column=0, sticky=tk.W, pady=3)
        method_cb = ttk.Combobox(frame, values=[m.value for m in PaymentMethod], state="readonly", width=18)
        method_cb.set(PaymentMethod.CASH.value)
        method_cb.grid(row=11, column=1, sticky=tk.W, pady=3)

        ttk.Label(frame, text="Payment Status:").grid(row=12, column=0, sticky=tk.W, pady=3)
        pay_cb = ttk.Combobox(frame, values=[p.value for p in PaymentStatus], state="readonly", width=18)
        pay_cb.set(PaymentStatus.PENDING.value)
        pay_cb.grid(row=12, column=1, sticky=tk.W, pady=3)

        def _save_order():
            raw_id = id_entry.get().strip()
            ok_id, id_val = validate_order_id(raw_id)
            if not ok_id:
                messagebox.showerror("Validation Error", id_val)
                return

            raw_name = name_entry.get().strip()
            ok_name, name_val = validate_customer_name(raw_name)
            if not ok_name:
                messagebox.showerror("Validation Error", name_val)
                return

            raw_phone = phone_entry.get().strip()
            ok_phone, phone_val = validate_phone(raw_phone)
            if not ok_phone:
                messagebox.showerror("Validation Error", phone_val)
                return

            raw_email = email_entry.get().strip()
            ok_email, email_val = validate_email(raw_email)
            if not ok_email:
                messagebox.showerror("Validation Error", email_val)
                return

            raw_item = item_entry.get().strip()
            if not raw_item:
                messagebox.showerror("Validation Error", "Item name cannot be empty.")
                return

            try:
                qty_val = int(qty_entry.get().strip())
                if qty_val < 1:
                    raise ValueError()
            except ValueError:
                messagebox.showerror("Validation Error", "Quantity must be an integer >= 1.")
                return

            try:
                price_val = float(price_entry.get().strip())
                if price_val <= 0:
                    raise ValueError()
            except ValueError:
                messagebox.showerror("Validation Error", "Unit price must be greater than $0.00.")
                return

            try:
                disc_val = float(disc_entry.get().strip())
                if not (0 <= disc_val <= 100):
                    raise ValueError()
            except ValueError:
                messagebox.showerror("Validation Error", "Discount must be between 0 and 100%.")
                return

            try:
                deliv_val = float(deliv_entry.get().strip())
                if deliv_val < 0:
                    raise ValueError()
            except ValueError:
                messagebox.showerror("Validation Error", "Delivery fee cannot be negative.")
                return

            item = OrderItem(name=raw_item, quantity=qty_val, unit_price=price_val)
            new_ord = Order(
                order_id=id_val,
                customer_name=name_val,
                customer_phone=phone_val,
                customer_email=email_val,
                items=[item],
                discount_pct=disc_val,
                delivery_fee=deliv_val,
                status=OrderStatus.PLACED,
                payment_status=PaymentStatus(pay_cb.get()),
                payment_method=PaymentMethod(method_cb.get()),
                notes="Created via GUI interface.",
            )

            ok, msg = self.manager.create_order(new_ord)
            if ok:
                messagebox.showinfo("Success", msg)
                dlg.destroy()
                self.refresh_table()
            else:
                messagebox.showerror("Error", msg)

        ttk.Button(frame, text="Submit Order", command=_save_order).grid(row=13, column=0, columnspan=2, pady=18)

    def show_analytics_dialog(self):
        analytics = OrderAnalytics(self.manager.get_all_orders())
        kpis = analytics.get_summary_kpis()
        status_df = analytics.get_status_distribution()

        dlg = tk.Toplevel(self.root)
        dlg.title("Executive Business Summary")
        dlg.geometry("540x500")

        txt = tk.Text(dlg, wrap=tk.WORD, font=("Consolas", 10), padx=10, pady=10)
        txt.pack(fill=tk.BOTH, expand=True)

        lines = [
            "EXECUTIVE BUSINESS SUMMARY",
            "=" * 50,
            f"Total Orders:          {kpis['total_orders']}",
            f"Total Gross Revenue:   ${kpis['total_revenue']:,.2f}",
            f"Paid Revenue:          ${kpis['paid_revenue']:,.2f}",
            f"Pending Receivables:   ${kpis['pending_revenue']:,.2f}",
            f"Average Order Value:   ${kpis['avg_order_value']:,.2f}",
            f"Total Items Sold:      {kpis['total_items_sold']} units",
            f"Completion Rate:       {kpis['completion_rate_pct']}%",
            f"Overdue Orders Alert:  {kpis['overdue_orders_count']} order(s)",
            "",
            "FULFILLMENT BREAKDOWN:",
            "-" * 50,
            f"{'Status':<14} | {'Count':<6} | {'Revenue ($)':<14}",
            "-" * 50,
        ]
        for _, r in status_df.iterrows():
            lines.append(f"{r['Status']:<14} | {int(r['Count']):<6} | ${r['Revenue ($)']:>12,.2f}")

        txt.insert(tk.END, "\n".join(lines))
        txt.configure(state="disabled")

    def bulk_import_csv(self):
        file_path = filedialog.askopenfilename(
            title="Select Legacy CSV File",
            filetypes=[("CSV Files", "*.csv"), ("All Files", "*.*")]
        )
        if not file_path:
            return

        result = BulkImporter.import_csv(file_path)
        msg = f"Bulk Import Summary:\n\nTotal Rows: {result.total_rows}\nValid: {result.successful_count}\nErrors: {result.error_count}\n\n"
        if result.successful_count > 0:
            if messagebox.askyesno("Commit Import", msg + f"Commit {result.successful_count} valid orders to database?"):
                for o in result.imported_orders:
                    self.manager.create_order(o)
                self.refresh_table()
                messagebox.showinfo("Done", f"Successfully imported {result.successful_count} orders!")
        else:
            messagebox.showwarning("Import Failed", msg + "No valid orders found to import.")

    def export_all_reports(self):
        analytics = OrderAnalytics(self.manager.get_all_orders())
        exporter = ReportExporter(analytics)
        md_path = exporter.export_markdown_report()
        sum_csv, ord_csv = exporter.export_csv_reports()
        chart_path = exporter.export_chart()

        msg = (
            f"Successfully exported reports:\n\n"
            f"• Markdown Report: {md_path.name}\n"
            f"• Sales Summary CSV: {sum_csv.name}\n"
            f"• Orders Export CSV: {ord_csv.name}\n"
            f"• Matplotlib Chart: {chart_path.name if chart_path else 'N/A'}\n\n"
            f"Stored in: {md_path.parent}"
        )
        messagebox.showinfo("Exports Complete", msg)

    def reload_sample_data(self):
        if messagebox.askyesno("Confirm Reload", "Reset and reload the 42 sample records into the active database?"):
            from src.seed_data import generate_sample_data
            generate_sample_data()
            self.manager.reload()
            self.refresh_table()
            messagebox.showinfo("Reloaded", "Successfully loaded 42 sample records!")


def launch_gui(manager: Optional[OrderManager] = None):
    """Entry point to launch GUI window."""
    mgr = manager or OrderManager()
    root = tk.Tk()
    app = OrderTrackerGUI(root, mgr)
    root.mainloop()


if __name__ == "__main__":
    launch_gui()
