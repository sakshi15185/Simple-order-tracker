"""
Application Configuration and Constants
Simple Order Tracker - Small Business & Retail (SmartCommunity Hack #85)
"""

from pathlib import Path
from enum import Enum

# Base directories
BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
REPORTS_DIR = BASE_DIR / "reports"

# Ensure essential directories exist
DATA_DIR.mkdir(parents=True, exist_ok=True)
REPORTS_DIR.mkdir(parents=True, exist_ok=True)

# File paths
ORDERS_JSON_PATH = DATA_DIR / "orders.json"
ORDERS_CSV_PATH = DATA_DIR / "orders.csv"
SAMPLE_ORDERS_JSON_PATH = DATA_DIR / "sample_orders.json"
LEGACY_SAMPLE_CSV_PATH = DATA_DIR / "legacy_import_sample.csv"
AUDIT_LOG_PATH = REPORTS_DIR / "audit_log.txt"

# Business logic rules
DEFAULT_TAX_RATE = 0.05  # 5% tax
DEFAULT_CURRENCY = "$"
OVERDUE_HOURS_THRESHOLD = 48  # Alert if Placed or Processing > 48h
HIGH_VALUE_THRESHOLD = 500.00  # Highlight orders over $500
PAGE_SIZE = 8  # Records per terminal page

# Order Status Definitions
class OrderStatus(str, Enum):
    PLACED = "PLACED"
    PROCESSING = "PROCESSING"
    SHIPPED = "SHIPPED"
    DELIVERED = "DELIVERED"
    CANCELLED = "CANCELLED"

# Allowed State Transitions
ALLOWED_TRANSITIONS = {
    OrderStatus.PLACED: [OrderStatus.PROCESSING, OrderStatus.CANCELLED],
    OrderStatus.PROCESSING: [OrderStatus.SHIPPED, OrderStatus.CANCELLED],
    OrderStatus.SHIPPED: [OrderStatus.DELIVERED],
    OrderStatus.DELIVERED: [],  # Terminal state
    OrderStatus.CANCELLED: [],  # Terminal state
}

# Payment Status Definitions
class PaymentStatus(str, Enum):
    PENDING = "PENDING"
    PAID = "PAID"
    REFUNDED = "REFUNDED"

# Payment Methods
class PaymentMethod(str, Enum):
    CASH = "CASH"
    CREDIT_CARD = "CREDIT_CARD"
    DEBIT_CARD = "DEBIT_CARD"
    UPI = "UPI"
    BANK_TRANSFER = "BANK_TRANSFER"

# ANSI Terminal Colors & Styling
class Colors:
    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    ITALIC = "\033[3m"
    UNDERLINE = "\033[4m"

    # Foreground
    RED = "\033[91m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    BLUE = "\033[94m"
    MAGENTA = "\033[95m"
    CYAN = "\033[96m"
    WHITE = "\033[97m"

    # Status-specific colors
    STATUS_COLORS = {
        OrderStatus.PLACED.value: YELLOW,
        OrderStatus.PROCESSING.value: BLUE,
        OrderStatus.SHIPPED.value: CYAN,
        OrderStatus.DELIVERED.value: GREEN,
        OrderStatus.CANCELLED.value: RED,
    }
