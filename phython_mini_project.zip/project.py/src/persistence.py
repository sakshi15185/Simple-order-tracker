"""
Local Data Persistence Module
Handles fault-tolerant serialization and deserialization to JSON and CSV formats with atomic writes,
schema validation, backup creation, and auto-recovery from corrupted files.
"""

import json
import csv
import shutil
from pathlib import Path
from datetime import datetime, timezone
from typing import List, Dict, Any, Tuple

from src.models import Order
from src.config import ORDERS_JSON_PATH, ORDERS_CSV_PATH, Colors


class PersistenceManager:
    """Manages file storage, schema validation, and recovery for Orders."""

    def __init__(self, json_path: Path = ORDERS_JSON_PATH, csv_path: Path = ORDERS_CSV_PATH):
        self.json_path = Path(json_path)
        self.csv_path = Path(csv_path)
        self._ensure_storage_ready()

    def _ensure_storage_ready(self) -> None:
        """Verifies directories exist and creates initial templates if missing."""
        self.json_path.parent.mkdir(parents=True, exist_ok=True)
        self.csv_path.parent.mkdir(parents=True, exist_ok=True)

        if not self.json_path.exists():
            self._save_raw_json([])

    def _save_raw_json(self, raw_data: List[Dict[str, Any]]) -> None:
        """Atomic write to JSON file via temporary file to prevent corruption."""
        tmp_path = self.json_path.with_suffix(".tmp")
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(raw_data, f, indent=2, ensure_ascii=False)
        shutil.move(str(tmp_path), str(self.json_path))

    def _sync_to_csv(self, orders: List[Order]) -> None:
        """Synchronizes an up-to-date flat CSV export of orders for external retail tools."""
        if not orders:
            # Empty file with standard headers
            with open(self.csv_path, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow([
                    "Order ID", "Customer Name", "Phone", "Email",
                    "Items Summary", "Items Count", "Subtotal ($)",
                    "Discount (%)", "Tax ($)", "Delivery Fee ($)",
                    "Total Amount ($)", "Status", "Payment Status",
                    "Payment Method", "Created At", "Updated At"
                ])
            return

        flat_records = [order.to_flat_dict() for order in orders]
        fieldnames = list(flat_records[0].keys())

        tmp_csv = self.csv_path.with_suffix(".tmp")
        with open(tmp_csv, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(flat_records)
        shutil.move(str(tmp_csv), str(self.csv_path))

    def load_orders(self) -> Tuple[List[Order], List[str]]:
        """
        Loads all orders from JSON storage.
        Detects FileNotFoundError, JSONDecodeError, or corrupted schema.
        Returns:
            (loaded_orders, error_warnings)
        """
        warnings: List[str] = []
        if not self.json_path.exists():
            self._save_raw_json([])
            return [], []

        try:
            with open(self.json_path, "r", encoding="utf-8") as f:
                content = f.read().strip()
                if not content:
                    return [], []
                raw_list = json.loads(content)

            if not isinstance(raw_list, list):
                raise ValueError("JSON root element must be a list of order objects.")

        except (json.JSONDecodeError, ValueError) as err:
            # Backup corrupted file with timestamp and initialize fresh template
            timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
            backup_path = self.json_path.with_suffix(f".corrupt_{timestamp}.bak")
            try:
                shutil.copy(str(self.json_path), str(backup_path))
                warnings.append(
                    f"Warning: Corrupted JSON detected ({err}). File backed up to {backup_path.name} "
                    "and fresh empty database initialized."
                )
            except Exception as copy_err:
                warnings.append(f"Could not backup corrupted file: {copy_err}")

            self._save_raw_json([])
            return [], warnings

        # Schema validation and deserialization
        orders: List[Order] = []
        for idx, item_data in enumerate(raw_list, 1):
            try:
                order = Order.from_dict(item_data)
                orders.append(order)
            except Exception as e:
                warnings.append(f"Row {idx} (ID: {item_data.get('order_id', 'unknown')}): Skipped invalid record - {e}")

        return orders, warnings

    def save_orders(self, orders: List[Order]) -> None:
        """Saves current orders to JSON and syncs CSV mirror atomically."""
        raw_data = [order.to_dict() for order in orders]
        self._save_raw_json(raw_data)
        self._sync_to_csv(orders)
