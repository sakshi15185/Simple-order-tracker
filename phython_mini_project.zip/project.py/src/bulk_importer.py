"""
Bulk Dataset Importer
Enables ingesting legacy CSV order datasets with format sanitization,
schema normalization, defensive row-by-row validation, and detailed audit error logs.
"""

import csv
from pathlib import Path
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import List, Dict, Tuple, Any

from src.models import Order, OrderItem, OrderStatus, PaymentStatus, PaymentMethod
from src.validator import (
    validate_order_id,
    validate_customer_name,
    validate_phone,
    validate_email,
    validate_quantity,
    validate_unit_price,
)
from src.config import REPORTS_DIR


@dataclass
class ImportResult:
    total_rows: int = 0
    successful_count: int = 0
    error_count: int = 0
    imported_orders: List[Order] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    log_file: str = ""


class BulkImporter:
    """Ingests legacy CSV records into standard Order entities."""

    @staticmethod
    def parse_legacy_items(raw_items_str: str) -> List[OrderItem]:
        """
        Parses item string. Supported formats:
        1. 'Coffee Beans:2:14.50; Ceramic Mug:1:12.00'
        2. 'Coffee Beans x2 @ 14.50'
        3. Simple name 'Artisan Bread' (defaults qty=1, price=10.0)
        """
        items: List[OrderItem] = []
        chunks = [c.strip() for c in raw_items_str.split(";") if c.strip()]
        for chunk in chunks:
            if ":" in chunk:
                parts = chunk.split(":")
                name = parts[0].strip()
                qty = int(parts[1].strip()) if len(parts) > 1 and parts[1].strip().isdigit() else 1
                price = float(parts[2].strip()) if len(parts) > 2 else 10.0
                items.append(OrderItem(name=name, quantity=qty, unit_price=price))
            else:
                items.append(OrderItem(name=chunk, quantity=1, unit_price=10.0))
        return items

    @classmethod
    def import_csv(cls, file_path: Path) -> ImportResult:
        result = ImportResult()
        path = Path(file_path)

        if not path.exists():
            result.errors.append(f"File not found: {file_path}")
            return result

        rows: List[Dict[str, str]] = []
        try:
            with open(path, "r", encoding="utf-8-sig") as f:
                reader = csv.DictReader(f)
                rows = list(reader)
        except Exception as e:
            result.errors.append(f"Failed to read CSV: {e}")
            return result

        result.total_rows = len(rows)

        # Normalize column mappings for varied legacy CSV headers
        for row_num, raw_row in enumerate(rows, start=2):  # Start at line 2 for headers
            # Normalize keys to lower-case stripped
            norm_row = {k.strip().lower().replace(" ", "_"): v.strip() for k, v in raw_row.items() if k}

            order_id_raw = norm_row.get("order_id") or norm_row.get("orderid") or norm_row.get("id") or ""
            name_raw = norm_row.get("customer_name") or norm_row.get("customer") or norm_row.get("name") or ""
            phone_raw = norm_row.get("customer_phone") or norm_row.get("phone") or "+1 555-0100"
            email_raw = norm_row.get("customer_email") or norm_row.get("email") or "legacy.customer@example.com"
            items_raw = norm_row.get("items") or norm_row.get("items_summary") or norm_row.get("product") or ""
            status_raw = (norm_row.get("status") or "PLACED").upper()
            pay_status_raw = (norm_row.get("payment_status") or norm_row.get("payment") or "PENDING").upper()
            pay_method_raw = (norm_row.get("payment_method") or "CASH").upper()

            # Row validation
            row_errors = []

            # 1. Order ID
            valid_id, id_val = validate_order_id(order_id_raw)
            if not valid_id:
                row_errors.append(f"Invalid Order ID '{order_id_raw}': {id_val}")

            # 2. Customer Name
            valid_name, name_val = validate_customer_name(name_raw)
            if not valid_name:
                row_errors.append(f"Invalid Customer Name '{name_raw}': {name_val}")

            # 3. Status checks
            if status_raw not in OrderStatus.__members__:
                row_errors.append(f"Invalid Status '{status_raw}'. Must be one of {[s.value for s in OrderStatus]}")

            if pay_status_raw not in PaymentStatus.__members__:
                pay_status_raw = PaymentStatus.PENDING.value

            if pay_method_raw not in PaymentMethod.__members__:
                pay_method_raw = PaymentMethod.CASH.value

            # 4. Items parsing
            items: List[OrderItem] = []
            if not items_raw:
                row_errors.append("Empty item list.")
            else:
                try:
                    items = cls.parse_legacy_items(items_raw)
                    if not items:
                        row_errors.append("No valid line items parsed.")
                except Exception as it_err:
                    row_errors.append(f"Failed to parse items: {it_err}")

            if row_errors:
                result.error_count += 1
                result.errors.append(f"Row {row_num} (ID: {order_id_raw or 'N/A'}): " + " | ".join(row_errors))
                continue

            # Construct Order object
            try:
                discount_raw = norm_row.get("discount_pct", "0.0").replace("%", "")
                delivery_raw = norm_row.get("delivery_fee", "0.0").replace("$", "")
                order = Order(
                    order_id=id_val,
                    customer_name=name_val,
                    customer_phone=phone_raw,
                    customer_email=email_raw,
                    items=items,
                    discount_pct=float(discount_raw or 0.0),
                    delivery_fee=float(delivery_raw or 0.0),
                    status=OrderStatus(status_raw),
                    payment_status=PaymentStatus(pay_status_raw),
                    payment_method=PaymentMethod(pay_method_raw),
                    notes="Imported via Bulk CSV Ingestion.",
                )
                result.imported_orders.append(order)
                result.successful_count += 1
            except Exception as build_err:
                result.error_count += 1
                result.errors.append(f"Row {row_num}: Build error - {build_err}")

        # Write Import Audit Log
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        log_path = REPORTS_DIR / f"import_log_{timestamp}.txt"
        with open(log_path, "w", encoding="utf-8") as f:
            f.write(f"=== Legacy CSV Bulk Import Log ===\n")
            f.write(f"Date/Time: {datetime.now(timezone.utc).isoformat()}\n")
            f.write(f"Source: {file_path}\n")
            f.write(f"Total Rows Processed: {result.total_rows}\n")
            f.write(f"Successfully Ingested: {result.successful_count}\n")
            f.write(f"Validation Failures: {result.error_count}\n\n")
            if result.errors:
                f.write("--- Error Breakdown ---\n")
                for err in result.errors:
                    f.write(f"[FAIL] {err}\n")
            else:
                f.write("All rows passed format validation cleanly!\n")

        result.log_file = str(log_path)
        return result
