"""
Core Business Logic Engine
Coordinates order life cycle, state machine updates, search/filtering queries,
and continuous audit logging.
"""

from typing import List, Dict, Optional, Tuple, Any
from datetime import datetime, timezone
from pathlib import Path

from src.models import Order, OrderStatus, PaymentStatus, PaymentMethod
from src.persistence import PersistenceManager
from src.config import (
    ORDERS_JSON_PATH,
    ORDERS_CSV_PATH,
    AUDIT_LOG_PATH,
    OVERDUE_HOURS_THRESHOLD,
    HIGH_VALUE_THRESHOLD,
)


class OrderManager:
    """Central business engine for Small Business & Retail Order Tracking."""

    def __init__(self, persistence: Optional[PersistenceManager] = None):
        self.persistence = persistence or PersistenceManager(ORDERS_JSON_PATH, ORDERS_CSV_PATH)
        self.orders: Dict[str, Order] = {}
        self.load_warnings: List[str] = []
        self.reload()

    def reload(self) -> None:
        """Reloads orders from local storage."""
        loaded, warnings = self.persistence.load_orders()
        self.orders = {order.order_id: order for order in loaded}
        self.load_warnings = warnings

    def _log_audit(self, action: str, order_id: str, details: str) -> None:
        """Appends an operational audit entry to reports/audit_log.txt."""
        AUDIT_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
        now_str = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        log_line = f"[{now_str}] ACTION: {action:<18} | Order: {order_id:<14} | {details}\n"
        try:
            with open(AUDIT_LOG_PATH, "a", encoding="utf-8") as f:
                f.write(log_line)
        except Exception:
            pass  # Non-blocking if file locked

    def get_all_orders(self) -> List[Order]:
        """Returns all orders sorted by creation timestamp descending."""
        return sorted(self.orders.values(), key=lambda o: o.created_at, reverse=True)

    def get_order(self, order_id: str) -> Optional[Order]:
        """Retrieves a single order by ID case-insensitively."""
        return self.orders.get(order_id.strip().upper())

    def generate_next_order_id(self, prefix: str = "ORD-2026-") -> str:
        """Generates the next sequential unique order identifier."""
        max_num = 1000
        for oid in self.orders.keys():
            if oid.startswith(prefix):
                suffix = oid[len(prefix):]
                if suffix.isdigit():
                    max_num = max(max_num, int(suffix))
        return f"{prefix}{max_num + 1}"

    def create_order(self, order: Order) -> Tuple[bool, str]:
        """Validates uniqueness and saves a newly created order."""
        if order.order_id in self.orders:
            return False, f"Order with ID '{order.order_id}' already exists."

        self.orders[order.order_id] = order
        self.persistence.save_orders(list(self.orders.values()))

        self._log_audit(
            action="ORDER_CREATED",
            order_id=order.order_id,
            details=f"Customer: {order.customer_name} | Items: {order.total_quantity} | Total: ${order.total_amount:.2f}",
        )
        return True, f"Order {order.order_id} recorded successfully."

    def update_order_status(self, order_id: str, new_status: OrderStatus, note: str = "") -> Tuple[bool, str]:
        """Transitions an order from its current status through the state machine."""
        order = self.get_order(order_id)
        if not order:
            return False, f"Order '{order_id}' not found."

        old_status = order.status.value
        try:
            order.transition_to(new_status, note=note)
        except ValueError as e:
            return False, str(e)

        self.persistence.save_orders(list(self.orders.values()))
        self._log_audit(
            action="STATUS_UPDATED",
            order_id=order.order_id,
            details=f"From: {old_status} -> To: {order.status.value} | Note: {note or 'None'}",
        )
        return True, f"Order {order_id} status updated to {new_status.value}."

    def update_payment_status(self, order_id: str, new_payment_status: PaymentStatus, note: str = "") -> Tuple[bool, str]:
        """Updates the payment status of an order."""
        order = self.get_order(order_id)
        if not order:
            return False, f"Order '{order_id}' not found."

        old_payment = order.payment_status.value
        order.payment_status = new_payment_status
        order.updated_at = datetime.now(timezone.utc).isoformat()
        self.persistence.save_orders(list(self.orders.values()))

        self._log_audit(
            action="PAYMENT_UPDATED",
            order_id=order.order_id,
            details=f"Payment status changed from {old_payment} -> {new_payment_status.value} | Note: {note or 'None'}",
        )
        return True, f"Order {order_id} payment status updated to {new_payment_status.value}."

    def delete_order(self, order_id: str) -> Tuple[bool, str]:
        """Removes an order if in PLACED or CANCELLED state (audit preserved)."""
        order = self.get_order(order_id)
        if not order:
            return False, f"Order '{order_id}' not found."

        if order.status not in (OrderStatus.PLACED, OrderStatus.CANCELLED):
            return False, f"Cannot delete order in '{order.status.value}' state. Must be CANCELLED first."

        del self.orders[order.order_id]
        self.persistence.save_orders(list(self.orders.values()))
        self._log_audit(
            action="ORDER_DELETED",
            order_id=order_id,
            details=f"Deleted order for {order.customer_name} (Total was: ${order.total_amount:.2f})",
        )
        return True, f"Order {order_id} removed successfully."

    def search_orders(
        self,
        keyword: Optional[str] = None,
        status: Optional[OrderStatus] = None,
        payment_status: Optional[PaymentStatus] = None,
        min_amount: Optional[float] = None,
        max_amount: Optional[float] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        sort_by: str = "date_desc",
    ) -> List[Order]:
        """
        Multi-criteria query and filtering engine.
        Keyword matches order ID, customer name, email, phone, or item names.
        """
        results: List[Order] = list(self.orders.values())

        if keyword:
            kw = keyword.strip().lower()
            results = [
                o for o in results
                if kw in o.order_id.lower()
                or kw in o.customer_name.lower()
                or kw in o.customer_phone.lower()
                or kw in o.customer_email.lower()
                or any(kw in item.name.lower() for item in o.items)
            ]

        if status:
            results = [o for o in results if o.status == status]

        if payment_status:
            results = [o for o in results if o.payment_status == payment_status]

        if min_amount is not None:
            results = [o for o in results if o.total_amount >= min_amount]

        if max_amount is not None:
            results = [o for o in results if o.total_amount <= max_amount]

        if start_date:
            results = [o for o in results if o.created_at[:10] >= start_date]

        if end_date:
            results = [o for o in results if o.created_at[:10] <= end_date]

        # Sorting
        if sort_by == "date_asc":
            results.sort(key=lambda o: o.created_at)
        elif sort_by == "amount_desc":
            results.sort(key=lambda o: o.total_amount, reverse=True)
        elif sort_by == "amount_asc":
            results.sort(key=lambda o: o.total_amount)
        elif sort_by == "id_asc":
            results.sort(key=lambda o: o.order_id)
        else:  # default date_desc
            results.sort(key=lambda o: o.created_at, reverse=True)

        return results

    def get_overdue_orders(self, hours_threshold: float = OVERDUE_HOURS_THRESHOLD) -> List[Order]:
        """Returns all active orders exceeding SLA turnaround limit."""
        return [o for o in self.orders.values() if o.is_overdue(hours_threshold)]

    def get_high_value_orders(self, threshold: float = HIGH_VALUE_THRESHOLD) -> List[Order]:
        """Returns orders that breach the high-value monitoring threshold."""
        return [o for o in self.orders.values() if o.total_amount >= threshold]

    def count(self) -> int:
        return len(self.orders)
