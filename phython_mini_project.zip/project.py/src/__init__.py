"""Simple Order Tracker Package"""
__version__ = "1.0.0"
