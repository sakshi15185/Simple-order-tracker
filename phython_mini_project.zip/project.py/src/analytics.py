"""
Executive Summary and Analytics Engine
Leverages Pandas and NumPy for vectorized table manipulation and exploratory aggregation.
Computes KPIs, status distributions, turnaround times, top products, and warning flags.
"""

from typing import List, Dict, Any, Optional
from datetime import datetime, timezone
import pandas as pd
import numpy as np

from src.models import Order
from src.config import OrderStatus, PaymentStatus, OVERDUE_HOURS_THRESHOLD, HIGH_VALUE_THRESHOLD


class OrderAnalytics:
    """Computes operational and financial aggregations across orders."""

    def __init__(self, orders: List[Order]):
        self.orders = orders
        self.df = self._build_dataframe(orders)

    def _build_dataframe(self, orders: List[Order]) -> pd.DataFrame:
        """Flattens order entities into a Pandas DataFrame."""
        if not orders:
            return pd.DataFrame()

        rows = []
        for o in orders:
            rows.append({
                "order_id": o.order_id,
                "customer_name": o.customer_name,
                "customer_phone": o.customer_phone,
                "customer_email": o.customer_email,
                "status": o.status.value,
                "payment_status": o.payment_status.value,
                "payment_method": o.payment_method.value,
                "items_count": o.total_quantity,
                "subtotal": o.subtotal,
                "discount_amount": o.discount_amount,
                "tax_amount": o.tax_amount,
                "delivery_fee": o.delivery_fee,
                "total_amount": o.total_amount,
                "created_at": o.created_at,
                "updated_at": o.updated_at,
                "is_overdue": o.is_overdue(),
                "is_high_value": o.total_amount >= HIGH_VALUE_THRESHOLD,
            })
        df = pd.DataFrame(rows)
        df["created_dt"] = pd.to_datetime(df["created_at"], errors="coerce")
        df["updated_dt"] = pd.to_datetime(df["updated_at"], errors="coerce")
        return df

    def get_summary_kpis(self) -> Dict[str, Any]:
        """Calculates core executive business KPIs."""
        if self.df.empty:
            return {
                "total_orders": 0,
                "total_revenue": 0.0,
                "paid_revenue": 0.0,
                "pending_revenue": 0.0,
                "refunded_revenue": 0.0,
                "avg_order_value": 0.0,
                "total_items_sold": 0,
                "total_discounts": 0.0,
                "total_tax": 0.0,
                "overdue_orders_count": 0,
                "high_value_orders_count": 0,
                "completion_rate_pct": 0.0,
            }

        total_orders = len(self.df)
        total_rev = float(self.df["total_amount"].sum())
        paid_rev = float(self.df[self.df["payment_status"] == PaymentStatus.PAID.value]["total_amount"].sum())
        pending_rev = float(self.df[self.df["payment_status"] == PaymentStatus.PENDING.value]["total_amount"].sum())
        refunded_rev = float(self.df[self.df["payment_status"] == PaymentStatus.REFUNDED.value]["total_amount"].sum())
        avg_order_val = float(self.df["total_amount"].mean())
        items_sold = int(self.df["items_count"].sum())
        discounts = float(self.df["discount_amount"].sum())
        tax = float(self.df["tax_amount"].sum())
        overdue_cnt = int(self.df["is_overdue"].sum())
        high_val_cnt = int(self.df["is_high_value"].sum())

        delivered_cnt = len(self.df[self.df["status"] == OrderStatus.DELIVERED.value])
        non_cancelled = len(self.df[self.df["status"] != OrderStatus.CANCELLED.value])
        completion_rate = (delivered_cnt / non_cancelled * 100.0) if non_cancelled > 0 else 0.0

        return {
            "total_orders": total_orders,
            "total_revenue": round(total_rev, 2),
            "paid_revenue": round(paid_rev, 2),
            "pending_revenue": round(pending_rev, 2),
            "refunded_revenue": round(refunded_rev, 2),
            "avg_order_value": round(avg_order_val, 2),
            "total_items_sold": items_sold,
            "total_discounts": round(discounts, 2),
            "total_tax": round(tax, 2),
            "overdue_orders_count": overdue_cnt,
            "high_value_orders_count": high_val_cnt,
            "completion_rate_pct": round(completion_rate, 1),
        }

    def get_status_distribution(self) -> pd.DataFrame:
        """Returns distribution counts, percentages, and revenue grouped by order status."""
        all_statuses = [s.value for s in OrderStatus]
        if self.df.empty:
            return pd.DataFrame({
                "Status": all_statuses,
                "Count": [0] * len(all_statuses),
                "Share (%)": [0.0] * len(all_statuses),
                "Revenue ($)": [0.0] * len(all_statuses),
            })

        grouped = self.df.groupby("status").agg(
            Count=("order_id", "count"),
            Revenue=("total_amount", "sum")
        ).reindex(all_statuses, fill_value=0)

        total_orders = len(self.df)
        grouped["Share (%)"] = ((grouped["Count"] / total_orders) * 100.0).round(1)
        grouped["Revenue ($)"] = grouped["Revenue"].round(2)
        grouped = grouped.reset_index().rename(columns={"status": "Status"})
        return grouped[["Status", "Count", "Share (%)", "Revenue ($)"]]

    def get_payment_distribution(self) -> pd.DataFrame:
        """Returns distribution by payment status."""
        all_pay_statuses = [p.value for p in PaymentStatus]
        if self.df.empty:
            return pd.DataFrame()

        grouped = self.df.groupby("payment_status").agg(
            Count=("order_id", "count"),
            Revenue=("total_amount", "sum")
        ).reindex(all_pay_statuses, fill_value=0)

        grouped["Revenue ($)"] = grouped["Revenue"].round(2)
        return grouped.reset_index().rename(columns={"payment_status": "Payment Status"})

    def get_top_products(self, top_n: int = 5) -> pd.DataFrame:
        """Aggregates product sales by quantity and revenue across line items."""
        if not self.orders:
            return pd.DataFrame(columns=["Product", "Qty Sold", "Total Revenue ($)"])

        items_list = []
        for o in self.orders:
            # exclude cancelled orders from sales stats
            if o.status == OrderStatus.CANCELLED:
                continue
            for it in o.items:
                items_list.append({
                    "product": it.name,
                    "quantity": it.quantity,
                    "revenue": it.subtotal,
                })

        if not items_list:
            return pd.DataFrame(columns=["Product", "Qty Sold", "Total Revenue ($)"])

        items_df = pd.DataFrame(items_list)
        grouped = items_df.groupby("product").agg(
            {"quantity": "sum", "revenue": "sum"}
        ).sort_values(by="revenue", ascending=False).head(top_n).reset_index()

        grouped = grouped.rename(columns={
            "product": "Product",
            "quantity": "Qty Sold",
            "revenue": "Total Revenue ($)"
        })
        grouped["Total Revenue ($)"] = grouped["Total Revenue ($)"].round(2)
        return grouped

    def get_top_customers(self, top_n: int = 5) -> pd.DataFrame:
        """Aggregates top customers by total order spend."""
        if self.df.empty:
            return pd.DataFrame(columns=["Customer", "Orders", "Total Spent ($)"])

        active_df = self.df[self.df["status"] != OrderStatus.CANCELLED.value]
        if active_df.empty:
            return pd.DataFrame(columns=["Customer", "Orders", "Total Spent ($)"])

        cust_df = active_df.groupby("customer_name").agg(
            Orders=("order_id", "count"),
            TotalSpent=("total_amount", "sum")
        ).sort_values(by="TotalSpent", ascending=False).head(top_n).reset_index()

        cust_df = cust_df.rename(columns={"customer_name": "Customer", "TotalSpent": "Total Spent ($)"})
        cust_df["Total Spent ($)"] = cust_df["Total Spent ($)"].round(2)
        return cust_df

    def get_average_turnaround_time_hours(self) -> Optional[float]:
        """Computes mean turnaround time from created to delivered for completed orders."""
        if self.df.empty:
            return None

        deliv_df = self.df[self.df["status"] == OrderStatus.DELIVERED.value]
        if deliv_df.empty:
            return None

        turnarounds = []
        for o in self.orders:
            if o.status == OrderStatus.DELIVERED and len(o.status_history) >= 2:
                # Find delivered timestamp
                deliv_entry = next((h for h in o.status_history if h.status == OrderStatus.DELIVERED.value), None)
                if deliv_entry:
                    try:
                        c_dt = datetime.fromisoformat(o.created_at)
                        d_dt = datetime.fromisoformat(deliv_entry.timestamp)
                        hrs = (d_dt - c_dt).total_seconds() / 3600.0
                        if hrs >= 0:
                            turnarounds.append(hrs)
                    except Exception:
                        pass

        if not turnarounds:
            return None
        return round(float(np.mean(turnarounds)), 1)
