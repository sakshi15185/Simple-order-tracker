"""
Data Models for Simple Order Tracker
Defines OrderItem, StatusHistoryEntry, and Order dataclasses with validation and financial logic.
"""

from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional

from src.config import (
    OrderStatus,
    PaymentStatus,
    PaymentMethod,
    ALLOWED_TRANSITIONS,
    DEFAULT_TAX_RATE,
    OVERDUE_HOURS_THRESHOLD,
)


@dataclass
class OrderItem:
    """Represents a single product line item in an order."""
    name: str
    quantity: int
    unit_price: float

    def __post_init__(self):
        if not self.name or not self.name.strip():
            raise ValueError("Item name cannot be empty.")
        self.name = self.name.strip()
        if not isinstance(self.quantity, int) or self.quantity < 1:
            raise ValueError("Quantity must be a positive integer (>= 1).")
        if self.unit_price <= 0:
            raise ValueError("Unit price must be greater than zero.")
        self.unit_price = round(float(self.unit_price), 2)

    @property
    def subtotal(self) -> float:
        return round(self.quantity * self.unit_price, 2)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "quantity": self.quantity,
            "unit_price": self.unit_price,
            "subtotal": self.subtotal,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "OrderItem":
        return cls(
            name=str(data.get("name", "")),
            quantity=int(data.get("quantity", 1)),
            unit_price=float(data.get("unit_price", 0.0)),
        )


@dataclass
class StatusHistoryEntry:
    """Audit log entry capturing state transitions."""
    status: str
    timestamp: str
    note: str = ""

    def to_dict(self) -> Dict[str, str]:
        return {
            "status": self.status,
            "timestamp": self.timestamp,
            "note": self.note,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, str]) -> "StatusHistoryEntry":
        return cls(
            status=data.get("status", OrderStatus.PLACED.value),
            timestamp=data.get("timestamp", datetime.now(timezone.utc).isoformat()),
            note=data.get("note", ""),
        )


@dataclass
class Order:
    """Core domain model representing a customer order."""
    order_id: str
    customer_name: str
    customer_phone: str
    customer_email: str
    items: List[OrderItem]
    discount_pct: float = 0.0
    delivery_fee: float = 0.0
    tax_rate: float = DEFAULT_TAX_RATE
    status: OrderStatus = OrderStatus.PLACED
    payment_status: PaymentStatus = PaymentStatus.PENDING
    payment_method: PaymentMethod = PaymentMethod.CASH
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    status_history: List[StatusHistoryEntry] = field(default_factory=list)
    notes: str = ""

    def __post_init__(self):
        # Validate order ID
        if not self.order_id or not self.order_id.strip():
            raise ValueError("Order ID cannot be empty.")
        self.order_id = self.order_id.strip().upper()

        # Validate customer name
        if not self.customer_name or not self.customer_name.strip():
            raise ValueError("Customer name cannot be empty.")
        self.customer_name = self.customer_name.strip()

        # Ensure items is not empty
        if not self.items:
            raise ValueError("Order must contain at least one item.")

        # Ensure discount percentage is in 0-100 range
        if not (0.0 <= self.discount_pct <= 100.0):
            raise ValueError("Discount percentage must be between 0 and 100.")
        self.discount_pct = round(float(self.discount_pct), 2)

        # Delivery fee check
        if self.delivery_fee < 0.0:
            raise ValueError("Delivery fee cannot be negative.")
        self.delivery_fee = round(float(self.delivery_fee), 2)

        # Tax rate check
        if self.tax_rate < 0.0:
            raise ValueError("Tax rate cannot be negative.")
        self.tax_rate = round(float(self.tax_rate), 4)

        # Convert enums if strings provided
        if isinstance(self.status, str):
            self.status = OrderStatus(self.status.upper())
        if isinstance(self.payment_status, str):
            self.payment_status = PaymentStatus(self.payment_status.upper())
        if isinstance(self.payment_method, str):
            self.payment_method = PaymentMethod(self.payment_method.upper())

        # Seed initial status history if empty
        if not self.status_history:
            self.status_history.append(
                StatusHistoryEntry(
                    status=self.status.value,
                    timestamp=self.created_at,
                    note="Initial order created.",
                )
            )

    @property
    def total_quantity(self) -> int:
        return sum(item.quantity for item in self.items)

    @property
    def subtotal(self) -> float:
        return round(sum(item.subtotal for item in self.items), 2)

    @property
    def discount_amount(self) -> float:
        return round(self.subtotal * (self.discount_pct / 100.0), 2)

    @property
    def taxable_amount(self) -> float:
        return round(max(0.0, self.subtotal - self.discount_amount), 2)

    @property
    def tax_amount(self) -> float:
        return round(self.taxable_amount * self.tax_rate, 2)

    @property
    def total_amount(self) -> float:
        return round(self.taxable_amount + self.tax_amount + self.delivery_fee, 2)

    def can_transition_to(self, target_status: OrderStatus) -> bool:
        """Evaluates whether the order can validly move to target_status."""
        allowed = ALLOWED_TRANSITIONS.get(self.status, [])
        return target_status in allowed

    def transition_to(self, target_status: OrderStatus, note: str = "") -> None:
        """Executes a validated state transition with audit trail."""
        if isinstance(target_status, str):
            target_status = OrderStatus(target_status.upper())

        if target_status == self.status:
            raise ValueError(f"Order {self.order_id} is already in status '{self.status.value}'.")

        allowed = ALLOWED_TRANSITIONS.get(self.status, [])
        if target_status not in allowed:
            allowed_names = [s.value for s in allowed] or ["None (terminal state)"]
            raise ValueError(
                f"Invalid transition from '{self.status.value}' to '{target_status.value}'. "
                f"Allowed next statuses: {', '.join(allowed_names)}."
            )

        now_iso = datetime.now(timezone.utc).isoformat()
        self.status = target_status
        self.updated_at = now_iso
        self.status_history.append(
            StatusHistoryEntry(
                status=target_status.value,
                timestamp=now_iso,
                note=note or f"Status transitioned to {target_status.value}.",
            )
        )

    def is_overdue(self, hours_threshold: float = OVERDUE_HOURS_THRESHOLD) -> bool:
        """Determines if the order has been pending past the SLA threshold."""
        if self.status not in (OrderStatus.PLACED, OrderStatus.PROCESSING):
            return False
        try:
            created_dt = datetime.fromisoformat(self.created_at)
            # Ensure timezone awareness
            if created_dt.tzinfo is None:
                created_dt = created_dt.replace(tzinfo=timezone.utc)
            now = datetime.now(timezone.utc)
            elapsed_hours = (now - created_dt).total_seconds() / 3600.0
            return elapsed_hours > hours_threshold
        except Exception:
            return False

    def to_dict(self) -> Dict[str, Any]:
        """Full dictionary representation suitable for JSON persistence."""
        return {
            "order_id": self.order_id,
            "customer_name": self.customer_name,
            "customer_phone": self.customer_phone,
            "customer_email": self.customer_email,
            "items": [item.to_dict() for item in self.items],
            "discount_pct": self.discount_pct,
            "delivery_fee": self.delivery_fee,
            "tax_rate": self.tax_rate,
            "subtotal": self.subtotal,
            "discount_amount": self.discount_amount,
            "tax_amount": self.tax_amount,
            "total_amount": self.total_amount,
            "status": self.status.value,
            "payment_status": self.payment_status.value,
            "payment_method": self.payment_method.value,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "status_history": [sh.to_dict() for sh in self.status_history],
            "notes": self.notes,
        }

    def to_flat_dict(self) -> Dict[str, Any]:
        """Flattened dictionary representation suitable for CSV export and tables."""
        items_summary = "; ".join(f"{it.name} (x{it.quantity} @ ${it.unit_price:.2f})" for it in self.items)
        return {
            "Order ID": self.order_id,
            "Customer Name": self.customer_name,
            "Phone": self.customer_phone,
            "Email": self.customer_email,
            "Items Summary": items_summary,
            "Items Count": self.total_quantity,
            "Subtotal ($)": f"{self.subtotal:.2f}",
            "Discount (%)": f"{self.discount_pct:.1f}%",
            "Tax ($)": f"{self.tax_amount:.2f}",
            "Delivery Fee ($)": f"{self.delivery_fee:.2f}",
            "Total Amount ($)": f"{self.total_amount:.2f}",
            "Status": self.status.value,
            "Payment Status": self.payment_status.value,
            "Payment Method": self.payment_method.value,
            "Created At": self.created_at[:19].replace("T", " "),
            "Updated At": self.updated_at[:19].replace("T", " "),
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Order":
        """Reconstructs Order object from stored dictionary."""
        raw_items = data.get("items", [])
        items = [OrderItem.from_dict(item_data) for item_data in raw_items]

        raw_history = data.get("status_history", [])
        status_history = [StatusHistoryEntry.from_dict(h) for h in raw_history]

        order = cls(
            order_id=str(data.get("order_id", "")),
            customer_name=str(data.get("customer_name", "")),
            customer_phone=str(data.get("customer_phone", "")),
            customer_email=str(data.get("customer_email", "")),
            items=items,
            discount_pct=float(data.get("discount_pct", 0.0)),
            delivery_fee=float(data.get("delivery_fee", 0.0)),
            tax_rate=float(data.get("tax_rate", DEFAULT_TAX_RATE)),
            status=OrderStatus(str(data.get("status", OrderStatus.PLACED.value)).upper()),
            payment_status=PaymentStatus(str(data.get("payment_status", PaymentStatus.PENDING.value)).upper()),
            payment_method=PaymentMethod(str(data.get("payment_method", PaymentMethod.CASH.value)).upper()),
            created_at=str(data.get("created_at", datetime.now(timezone.utc).isoformat())),
            updated_at=str(data.get("updated_at", datetime.now(timezone.utc).isoformat())),
            status_history=status_history,
            notes=str(data.get("notes", "")),
        )
        return order
