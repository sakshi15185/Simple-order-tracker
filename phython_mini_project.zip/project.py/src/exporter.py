"""
Multi-Format Export Engine
Exports executive summary reports to Markdown, plain-text audit records,
standardized CSV summaries, and Matplotlib data visualization charts.
"""

from pathlib import Path
from datetime import datetime, timezone
from typing import Optional, Tuple
import matplotlib
# Use Agg backend for non-interactive headless PNG generation
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

from src.analytics import OrderAnalytics
from src.config import REPORTS_DIR, OrderStatus, Colors


class ReportExporter:
    """Handles multi-format export of order tracker summaries."""

    def __init__(self, analytics: OrderAnalytics, reports_dir: Path = REPORTS_DIR):
        self.analytics = analytics
        self.reports_dir = Path(reports_dir)
        self.reports_dir.mkdir(parents=True, exist_ok=True)

    def export_markdown_report(self, filename: str = "executive_summary.md") -> Path:
        """Generates a comprehensive Markdown executive report."""
        out_path = self.reports_dir / filename
        kpis = self.analytics.get_summary_kpis()
        status_df = self.analytics.get_status_distribution()
        pay_df = self.analytics.get_payment_distribution()
        top_prod_df = self.analytics.get_top_products(5)
        top_cust_df = self.analytics.get_top_customers(5)
        avg_turnaround = self.analytics.get_average_turnaround_time_hours()
        now_str = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")

        lines = [
            "# Simple Order Tracker - Executive Business Report",
            f"**Generated:** {now_str}  ",
            "**Domain:** Small Business & Retail | SmartCommunity Hack #85  ",
            "",
            "---",
            "",
            "## 1. Executive Key Performance Indicators (KPIs)",
            "",
            "| Metric | Value |",
            "| :--- | :--- |",
            f"| **Total Orders Logged** | {kpis['total_orders']} |",
            f"| **Total Gross Revenue** | ${kpis['total_revenue']:,.2f} |",
            f"| **Collected / Paid Revenue** | ${kpis['paid_revenue']:,.2f} |",
            f"| **Pending Receivables** | ${kpis['pending_revenue']:,.2f} |",
            f"| **Average Order Value (AOV)** | ${kpis['avg_order_value']:,.2f} |",
            f"| **Total Line Items Sold** | {kpis['total_items_sold']} units |",
            f"| **Discounts Applied** | ${kpis['total_discounts']:,.2f} |",
            f"| **Tax Collected (5%)** | ${kpis['total_tax']:,.2f} |",
            f"| **Fulfillment Completion Rate** | {kpis['completion_rate_pct']}% |",
            f"| **Average Fulfillment SLA** | {f'{avg_turnaround} hours' if avg_turnaround else 'N/A'} |",
            f"| **Overdue Orders Alert** | {kpis['overdue_orders_count']} order(s) |",
            f"| **High-Value Orders (>$500)** | {kpis['high_value_orders_count']} order(s) |",
            "",
            "---",
            "",
            "## 2. Order Status Distribution",
            "",
            "| Status | Count | Share (%) | Revenue ($) |",
            "| :--- | :---: | :---: | :---: |",
        ]

        for _, row in status_df.iterrows():
            lines.append(f"| **{row['Status']}** | {int(row['Count'])} | {row['Share (%)']}% | ${row['Revenue ($)']:,.2f} |")

        lines.extend([
            "",
            "---",
            "",
            "## 3. Payment Status Breakdown",
            "",
            "| Payment Status | Count | Revenue ($) |",
            "| :--- | :---: | :---: |",
        ])

        for _, row in pay_df.iterrows():
            lines.append(f"| **{row['Payment Status']}** | {int(row['Count'])} | ${row['Revenue ($)']:,.2f} |")

        lines.extend([
            "",
            "---",
            "",
            "## 4. Top 5 Best-Selling Products",
            "",
            "| Product Description | Quantity Sold | Total Revenue ($) |",
            "| :--- | :---: | :---: |",
        ])

        if top_prod_df.empty:
            lines.append("| *No product sales recorded* | - | - |")
        else:
            for _, row in top_prod_df.iterrows():
                lines.append(f"| {row['Product']} | {int(row['Qty Sold'])} | ${row['Total Revenue ($)']:,.2f} |")

        lines.extend([
            "",
            "---",
            "",
            "## 5. Top 5 Customers by Spend",
            "",
            "| Customer Name | Orders Placed | Total Spent ($) |",
            "| :--- | :---: | :---: |",
        ])

        if top_cust_df.empty:
            lines.append("| *No customer records available* | - | - |")
        else:
            for _, row in top_cust_df.iterrows():
                lines.append(f"| {row['Customer']} | {int(row['Orders'])} | ${row['Total Spent ($)']:,.2f} |")

        lines.extend([
            "",
            "---",
            "",
            "## 6. Threshold Warnings & Operational Flags",
            "",
        ])

        overdue_orders = [o for o in self.analytics.orders if o.is_overdue()]
        if overdue_orders:
            lines.append(f"> [!WARNING] **{len(overdue_orders)} Overdue Order(s) Exceeding 48h SLA:**")
            for o in overdue_orders:
                lines.append(f"- **{o.order_id}** | Customer: {o.customer_name} | Status: {o.status.value} | Created: {o.created_at[:10]}")
        else:
            lines.append("> [!NOTE] All active orders are within normal SLA turnaround parameters.")

        high_val_orders = [o for o in self.analytics.orders if o.total_amount >= 500.0]
        if high_val_orders:
            lines.append("")
            lines.append(f"> [!IMPORTANT] **{len(high_val_orders)} High-Value Order(s) (>= $500.00):**")
            for o in high_val_orders:
                lines.append(f"- **{o.order_id}** | Customer: {o.customer_name} | Total: ${o.total_amount:.2f} | Status: {o.status.value}")

        with open(out_path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")

        return out_path

    def export_csv_reports(self) -> Tuple[Path, Path]:
        """Exports standardized CSV summary and flat orders list."""
        summary_path = self.reports_dir / "sales_summary.csv"
        orders_path = self.reports_dir / "orders_export.csv"

        # 1. Sales Summary CSV
        status_df = self.analytics.get_status_distribution()
        status_df.to_csv(summary_path, index=False, encoding="utf-8")

        # 2. Detailed Orders Flat CSV
        if self.analytics.orders:
            flat_rows = [o.to_flat_dict() for o in self.analytics.orders]
            pd.DataFrame(flat_rows).to_csv(orders_path, index=False, encoding="utf-8")
        else:
            pd.DataFrame().to_csv(orders_path, index=False, encoding="utf-8")

        return summary_path, orders_path

    def export_chart(self, filename: str = "orders_analytics.png") -> Optional[Path]:
        """Generates a professional 4-panel Matplotlib dashboard image."""
        if not self.analytics.orders:
            return None

        out_path = self.reports_dir / filename
        fig, axes = plt.subplots(2, 2, figsize=(14, 10))
        fig.suptitle("Simple Order Tracker - Visual Analytics Dashboard", fontsize=16, fontweight="bold", y=0.98)

        # 1. Status Distribution (Donut Chart)
        ax1 = axes[0, 0]
        status_df = self.analytics.get_status_distribution()
        non_zero_status = status_df[status_df["Count"] > 0]

        color_palette = {
            OrderStatus.PLACED.value: "#F59E0B",      # Amber
            OrderStatus.PROCESSING.value: "#3B82F6",  # Blue
            OrderStatus.SHIPPED.value: "#06B6D4",     # Cyan
            OrderStatus.DELIVERED.value: "#10B981",   # Green
            OrderStatus.CANCELLED.value: "#EF4444",   # Red
        }
        colors = [color_palette.get(s, "#9CA3AF") for s in non_zero_status["Status"]]

        if not non_zero_status.empty:
            wedges, texts, autotexts = ax1.pie(
                non_zero_status["Count"],
                labels=non_zero_status["Status"],
                autopct="%1.1f%%",
                startangle=140,
                colors=colors,
                wedgeprops=dict(width=0.45, edgecolor="white", linewidth=2)
            )
            for autotext in autotexts:
                autotext.set_color("black")
                autotext.set_fontsize(9)
                autotext.set_weight("bold")
            ax1.set_title("Order Volume by Status", fontsize=12, fontweight="bold", pad=10)
        else:
            ax1.text(0.5, 0.5, "No Orders Recorded", ha="center", va="center")

        # 2. Revenue by Status (Bar Chart)
        ax2 = axes[0, 1]
        bars = ax2.bar(
            status_df["Status"],
            status_df["Revenue ($)"],
            color=[color_palette.get(s, "#9CA3AF") for s in status_df["Status"]],
            edgecolor="black",
            linewidth=0.8,
        )
        ax2.set_title("Total Revenue by Order Status ($)", fontsize=12, fontweight="bold", pad=10)
        ax2.set_ylabel("Revenue ($)")
        ax2.grid(axis="y", linestyle="--", alpha=0.5)
        for bar in bars:
            height = bar.get_height()
            if height > 0:
                ax2.annotate(
                    f"${height:,.0f}",
                    xy=(bar.get_x() + bar.get_width() / 2, height),
                    xytext=(0, 3),
                    textcoords="offset points",
                    ha="center", va="bottom", fontsize=8, fontweight="bold"
                )

        # 3. Top 5 Products by Revenue (Horizontal Bar Chart)
        ax3 = axes[1, 0]
        top_prod = self.analytics.get_top_products(5)
        if not top_prod.empty:
            # reverse order for descending top-to-bottom
            top_prod_rev = top_prod.iloc[::-1]
            hbars = ax3.barh(top_prod_rev["Product"], top_prod_rev["Total Revenue ($)"], color="#6366F1")
            ax3.set_title("Top 5 Products by Revenue ($)", fontsize=12, fontweight="bold", pad=10)
            ax3.set_xlabel("Revenue ($)")
            ax3.grid(axis="x", linestyle="--", alpha=0.5)
            for bar in hbars:
                width = bar.get_width()
                ax3.annotate(
                    f" ${width:,.0f}",
                    xy=(width, bar.get_y() + bar.get_height() / 2),
                    xytext=(3, 0),
                    textcoords="offset points",
                    ha="left", va="center", fontsize=8, fontweight="bold"
                )
        else:
            ax3.text(0.5, 0.5, "No Product Data", ha="center", va="center")

        # 4. Payment Status Distribution (Bar Chart)
        ax4 = axes[1, 1]
        pay_df = self.analytics.get_payment_distribution()
        pay_colors = {"PAID": "#10B981", "PENDING": "#F59E0B", "REFUNDED": "#EF4444"}
        if not pay_df.empty:
            pbars = ax4.bar(
                pay_df["Payment Status"],
                pay_df["Revenue ($)"],
                color=[pay_colors.get(p, "#9CA3AF") for p in pay_df["Payment Status"]],
                edgecolor="black",
                linewidth=0.8
            )
            ax4.set_title("Revenue by Payment Status ($)", fontsize=12, fontweight="bold", pad=10)
            ax4.set_ylabel("Revenue ($)")
            ax4.grid(axis="y", linestyle="--", alpha=0.5)
            for bar in pbars:
                height = bar.get_height()
                if height > 0:
                    ax4.annotate(
                        f"${height:,.0f}",
                        xy=(bar.get_x() + bar.get_width() / 2, height),
                        xytext=(0, 3),
                        textcoords="offset points",
                        ha="center", va="bottom", fontsize=8, fontweight="bold"
                    )
        else:
            ax4.text(0.5, 0.5, "No Payment Data", ha="center", va="center")

        plt.tight_layout(rect=[0, 0.03, 1, 0.95])
        fig.savefig(out_path, dpi=200)
        plt.close(fig)
        return out_path
