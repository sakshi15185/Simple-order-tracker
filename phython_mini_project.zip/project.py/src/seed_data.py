"""
Generates 42 realistic small business & retail sample orders spanning all statuses,
edge cases, boundary values, and overdue alerts.
Also creates a legacy import sample CSV with valid and invalid rows for testing.
"""

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path

from src.models import Order, OrderItem, StatusHistoryEntry
from src.config import (
    OrderStatus,
    PaymentStatus,
    PaymentMethod,
    DATA_DIR,
    SAMPLE_ORDERS_JSON_PATH,
    LEGACY_SAMPLE_CSV_PATH,
    ORDERS_JSON_PATH,
    ORDERS_CSV_PATH,
)
from src.persistence import PersistenceManager


def generate_sample_data():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    now = datetime.now(timezone.utc)

    # 42 realistic small business & retail orders
    orders_data = [
        # 1. Normal coffee & bakery order (Delivered)
        {
            "id": "ORD-2026-1001", "name": "Elena Rostova", "phone": "+1 555-0144", "email": "elena.r@example.com",
            "items": [("Artisan Sourdough Loaf", 2, 7.50), ("Ethiopian Yirgacheffe Beans (250g)", 1, 16.00)],
            "discount": 5.0, "delivery": 3.50, "status": OrderStatus.DELIVERED,
            "pay_status": PaymentStatus.PAID, "pay_method": PaymentMethod.CREDIT_CARD,
            "age_days": 6, "delivered_days_after": 1.2, "notes": "Leave at front porch."
        },
        # 2. Coffee shop supplies (Processing)
        {
            "id": "ORD-2026-1002", "name": "Marcus Chen", "phone": "+1 555-0182", "email": "marcus.c@example.com",
            "items": [("Ceramic Pour-Over Dripper", 1, 28.00), ("Paper Filters Pack (100ct)", 2, 6.50)],
            "discount": 0.0, "delivery": 4.00, "status": OrderStatus.PROCESSING,
            "pay_status": PaymentStatus.PAID, "pay_method": PaymentMethod.UPI,
            "age_days": 1, "delivered_days_after": None, "notes": "Gift wrap requested."
        },
        # 3. High-Value Boutique Ceramics (Delivered)
        {
            "id": "ORD-2026-1003", "name": "Sophia Vance", "phone": "+1 555-0199", "email": "sophia.v@designstudio.org",
            "items": [("Handmade Stoneware Dinner Set (16pc)", 1, 380.00), ("Matching Serving Platter", 2, 75.00)],
            "discount": 10.0, "delivery": 15.00, "status": OrderStatus.DELIVERED,
            "pay_status": PaymentStatus.PAID, "pay_method": PaymentMethod.BANK_TRANSFER,
            "age_days": 8, "delivered_days_after": 2.5, "notes": "Fragile freight shipment."
        },
        # 4. Overdue Order (Placed 4 days ago, still Placed! -> OVERDUE WARNING)
        {
            "id": "ORD-2026-1004", "name": "David K. Miller", "phone": "+1 555-0211", "email": "dkmiller@gmail.com",
            "items": [("Vintage Leather Journal", 1, 34.00), ("Brass Fountain Pen", 1, 45.00)],
            "discount": 0.0, "delivery": 5.00, "status": OrderStatus.PLACED,
            "pay_status": PaymentStatus.PENDING, "pay_method": PaymentMethod.CASH,
            "age_days": 4, "delivered_days_after": None, "notes": "Awaiting customer phone confirmation."
        },
        # 5. Overdue Order (Processing for 3 days -> OVERDUE WARNING)
        {
            "id": "ORD-2026-1005", "name": "Priya Sharma", "phone": "+91 98765-43210", "email": "priya.sharma@techcorp.in",
            "items": [("Organic Lavender Candle (Large)", 3, 22.00), ("Diffuser Oil Set", 1, 38.00)],
            "discount": 15.0, "delivery": 0.0, "status": OrderStatus.PROCESSING,
            "pay_status": PaymentStatus.PAID, "pay_method": PaymentMethod.UPI,
            "age_days": 3, "delivered_days_after": None, "notes": "Store pickup order pending stock restock."
        },
        # 6. Shipped Order
        {
            "id": "ORD-2026-1006", "name": "Lucas Dubois", "phone": "+33 6 12 34 56 78", "email": "lucas.dubois@mail.fr",
            "items": [("Botanical Watercolor Print (A3)", 2, 29.00), ("Oak Wood Frame", 2, 24.50)],
            "discount": 0.0, "delivery": 8.00, "status": OrderStatus.SHIPPED,
            "pay_status": PaymentStatus.PAID, "pay_method": PaymentMethod.DEBIT_CARD,
            "age_days": 2, "delivered_days_after": None, "notes": "Dispatched via DHL Express."
        },
        # 7. Cancelled Order
        {
            "id": "ORD-2026-1007", "name": "Amina Al-Mansoor", "phone": "+1 555-0322", "email": "amina.mansoor@webmail.com",
            "items": [("Specialty Cold Brew Keg (5L)", 1, 85.00)],
            "discount": 0.0, "delivery": 10.00, "status": OrderStatus.CANCELLED,
            "pay_status": PaymentStatus.REFUNDED, "pay_method": PaymentMethod.CREDIT_CARD,
            "age_days": 5, "delivered_days_after": None, "notes": "Customer requested cancellation before fulfillment."
        },
        # 8. Boundary Test: 0% discount, zero delivery fee, single item
        {
            "id": "ORD-2026-1008", "name": "Liam O'Connor", "phone": "+1 555-0355", "email": "liam.oc@celtic.ie",
            "items": [("Espresso Roast Sample Pack", 1, 12.00)],
            "discount": 0.0, "delivery": 0.0, "status": OrderStatus.DELIVERED,
            "pay_status": PaymentStatus.PAID, "pay_method": PaymentMethod.CASH,
            "age_days": 7, "delivered_days_after": 0.8, "notes": "Local walk-in counter purchase."
        },
        # 9. Boundary Test: 50% discount promotional campaign
        {
            "id": "ORD-2026-1009", "name": "Chloe Bennett", "phone": "+1 555-0412", "email": "chloe.b@influencer.co",
            "items": [("Silk Sleep Mask", 2, 32.00), ("Rosewater Facial Mist", 2, 21.00)],
            "discount": 50.0, "delivery": 4.50, "status": OrderStatus.DELIVERED,
            "pay_status": PaymentStatus.PAID, "pay_method": PaymentMethod.CREDIT_CARD,
            "age_days": 10, "delivered_days_after": 1.5, "notes": "Promo coupon 'VIP50' applied."
        },
        # 10. High-Value Order ($700+)
        {
            "id": "ORD-2026-1010", "name": "James Henderson", "phone": "+1 555-0488", "email": "j.henderson@apexcorp.com",
            "items": [("Smart Espresso Grinder Pro", 1, 550.00), ("Acaia Digital Scale", 1, 175.00)],
            "discount": 5.0, "delivery": 0.0, "status": OrderStatus.SHIPPED,
            "pay_status": PaymentStatus.PAID, "pay_method": PaymentMethod.BANK_TRANSFER,
            "age_days": 1, "delivered_days_after": None, "notes": "Commercial customer account."
        },
        # 11. Fresh order placed 2 hours ago (Normal Placed)
        {
            "id": "ORD-2026-1011", "name": "Zoe Kravitz", "phone": "+1 555-0520", "email": "zoe.k@artsy.com",
            "items": [("Matcha Whisk & Bowl Set", 1, 42.00), ("Ceremonial Grade Matcha (50g)", 2, 28.00)],
            "discount": 10.0, "delivery": 3.00, "status": OrderStatus.PLACED,
            "pay_status": PaymentStatus.PAID, "pay_method": PaymentMethod.UPI,
            "age_days": 0.1, "delivered_days_after": None, "notes": "Please include brewing guide."
        },
        # 12. Multi-Item Order (5 distinct items)
        {
            "id": "ORD-2026-1012", "name": "Benjamin Walker", "phone": "+1 555-0567", "email": "ben.walker@gmail.com",
            "items": [
                ("Dark Chocolate Truffles Box", 2, 18.00),
                ("Salted Caramel Macarons (6pk)", 1, 15.00),
                ("Earl Grey Tea Tin", 1, 14.50),
                ("Almond Biscotti", 3, 4.00),
                ("Honey Comb Jar (250g)", 1, 11.00),
            ],
            "discount": 8.0, "delivery": 5.00, "status": OrderStatus.PROCESSING,
            "pay_status": PaymentStatus.PAID, "pay_method": PaymentMethod.CREDIT_CARD,
            "age_days": 0.5, "delivered_days_after": None, "notes": "Gift basket assembly."
        },
        # 13. Delivered order
        {
            "id": "ORD-2026-1013", "name": "Fatima Noor", "phone": "+1 555-0601", "email": "fatima.noor@consultancy.com",
            "items": [("Bamboo Desk Organizer", 1, 38.00), ("Recycled Paper Notebook", 3, 8.50)],
            "discount": 0.0, "delivery": 4.50, "status": OrderStatus.DELIVERED,
            "pay_status": PaymentStatus.PAID, "pay_method": PaymentMethod.DEBIT_CARD,
            "age_days": 4, "delivered_days_after": 1.1, "notes": "Delivered to office reception."
        },
        # 14. Placed, pending cash on delivery
        {
            "id": "ORD-2026-1014", "name": "Rajesh Patel", "phone": "+91 91234-56789", "email": "rajesh.patel@business.in",
            "items": [("Indian Spices Gift Box", 2, 35.00), ("Brass Masala Dabba", 1, 48.00)],
            "discount": 5.0, "delivery": 6.00, "status": OrderStatus.PLACED,
            "pay_status": PaymentStatus.PENDING, "pay_method": PaymentMethod.CASH,
            "age_days": 0.3, "delivered_days_after": None, "notes": "Cash on delivery requested."
        },
        # 15. Delivered coffee beans bulk
        {
            "id": "ORD-2026-1015", "name": "Sarah Jenkins", "phone": "+1 555-0678", "email": "sjenkins@roastery.org",
            "items": [("Colombian Supremo Beans (1kg)", 3, 32.00)],
            "discount": 10.0, "delivery": 0.0, "status": OrderStatus.DELIVERED,
            "pay_status": PaymentStatus.PAID, "pay_method": PaymentMethod.CREDIT_CARD,
            "age_days": 9, "delivered_days_after": 2.0, "notes": "Weekly recurring order."
        },
        # 16. Processing order
        {
            "id": "ORD-2026-1016", "name": "Carlos Gomez", "phone": "+1 555-0722", "email": "carlos.gomez@latam.net",
            "items": [("Hand-carved Wooden Spoon Set", 1, 26.00), ("Linen Kitchen Towel", 2, 14.00)],
            "discount": 0.0, "delivery": 4.00, "status": OrderStatus.PROCESSING,
            "pay_status": PaymentStatus.PAID, "pay_method": PaymentMethod.UPI,
            "age_days": 0.8, "delivered_days_after": None, "notes": "Customer requested eco packaging."
        },
        # 17. Shipped order
        {
            "id": "ORD-2026-1017", "name": "Emily Watson", "phone": "+44 20 7946 0912", "email": "emily.w@londonbooks.uk",
            "items": [("Classic Hardcover Fiction (Set of 3)", 1, 65.00), ("Engraved Bookmark", 1, 15.00)],
            "discount": 0.0, "delivery": 7.50, "status": OrderStatus.SHIPPED,
            "pay_status": PaymentStatus.PAID, "pay_method": PaymentMethod.CREDIT_CARD,
            "age_days": 1.5, "delivered_days_after": None, "notes": "International air parcel."
        },
        # 18. Cancelled order
        {
            "id": "ORD-2026-1018", "name": "Vikram Malhotra", "phone": "+91 98111-22334", "email": "vikram.m@investments.in",
            "items": [("Smart Coffee Tumbler (Self-Heating)", 1, 149.00)],
            "discount": 0.0, "delivery": 5.00, "status": OrderStatus.CANCELLED,
            "pay_status": PaymentStatus.REFUNDED, "pay_method": PaymentMethod.UPI,
            "age_days": 6, "delivered_days_after": None, "notes": "Duplicate order placed by mistake."
        },
        # 19. High-Value Order ($620)
        {
            "id": "ORD-2026-1019", "name": "Natasha Romanoff", "phone": "+1 555-0899", "email": "natasha.r@shield.gov",
            "items": [("Specialty Nitro Cold Brew System", 1, 620.00)],
            "discount": 0.0, "delivery": 25.00, "status": OrderStatus.DELIVERED,
            "pay_status": PaymentStatus.PAID, "pay_method": PaymentMethod.BANK_TRANSFER,
            "age_days": 12, "delivered_days_after": 3.0, "notes": "Signature required upon delivery."
        },
        # 20. Overdue Order (Placed 5 days ago -> OVERDUE WARNING)
        {
            "id": "ORD-2026-1020", "name": "Arthur Dent", "phone": "+44 20 7123 4567", "email": "arthur.dent@galaxy.co.uk",
            "items": [("Sub-Etha Tea Towel", 2, 19.50), ("Guide to Galaxy Paperback", 1, 24.00)],
            "discount": 0.0, "delivery": 5.00, "status": OrderStatus.PLACED,
            "pay_status": PaymentStatus.PENDING, "pay_method": PaymentMethod.CASH,
            "age_days": 5, "delivered_days_after": None, "notes": "Customer uncontactable on phone."
        },
        # 21-42: Realistic diverse orders
        {
            "id": "ORD-2026-1021", "name": "Grace Hopper", "phone": "+1 555-0910", "email": "ghopper@navy.mil",
            "items": [("Nanosecond Copper Wire Souvenir", 10, 5.00), ("Vintage Logic Gate Mug", 2, 18.00)],
            "discount": 10.0, "delivery": 4.00, "status": OrderStatus.DELIVERED,
            "pay_status": PaymentStatus.PAID, "pay_method": PaymentMethod.CREDIT_CARD,
            "age_days": 14, "delivered_days_after": 1.4, "notes": "Delivered to CS lab."
        },
        {
            "id": "ORD-2026-1022", "name": "Daniel Craig", "phone": "+44 20 7007 0007", "email": "agent007@mi6.gov.uk",
            "items": [("Martini Shaker Steel (Professional)", 1, 55.00), ("Cocktail Glasses (Set of 4)", 1, 45.00)],
            "discount": 0.0, "delivery": 10.00, "status": OrderStatus.DELIVERED,
            "pay_status": PaymentStatus.PAID, "pay_method": PaymentMethod.CREDIT_CARD,
            "age_days": 7, "delivered_days_after": 1.0, "notes": "Shaken, not stirred."
        },
        {
            "id": "ORD-2026-1023", "name": "Maya Lin", "phone": "+1 555-1034", "email": "maya.lin@architecture.org",
            "items": [("Drafting Mechanical Pencil Set", 2, 38.00), ("Heavyweight Tracing Paper Roll", 1, 22.00)],
            "discount": 5.0, "delivery": 6.00, "status": OrderStatus.PROCESSING,
            "pay_status": PaymentStatus.PAID, "pay_method": PaymentMethod.DEBIT_CARD,
            "age_days": 0.6, "delivered_days_after": None, "notes": "Architectural studio address."
        },
        {
            "id": "ORD-2026-1024", "name": "Kenji Sato", "phone": "+81 90 1234 5678", "email": "kenji.sato@tokyo.jp",
            "items": [("Kyoto Ceramic Matcha Chawan", 1, 88.00), ("Bamboo Chasen Whisk", 1, 24.00)],
            "discount": 0.0, "delivery": 12.00, "status": OrderStatus.SHIPPED,
            "pay_status": PaymentStatus.PAID, "pay_method": PaymentMethod.CREDIT_CARD,
            "age_days": 2.2, "delivered_days_after": None, "notes": "Direct EMS courier dispatch."
        },
        {
            "id": "ORD-2026-1025", "name": "Isabella Rossi", "phone": "+39 06 6987 1234", "email": "isabella.rossi@roma.it",
            "items": [("Extra Virgin Olive Oil (Cold Pressed 750ml)", 3, 24.00), ("Balsamic Glaze di Modena", 2, 18.50)],
            "discount": 12.0, "delivery": 8.00, "status": OrderStatus.DELIVERED,
            "pay_status": PaymentStatus.PAID, "pay_method": PaymentMethod.CREDIT_CARD,
            "age_days": 11, "delivered_days_after": 2.1, "notes": "Carefully packaged with air pillows."
        },
        {
            "id": "ORD-2026-1026", "name": "Liam Nelson", "phone": "+1 555-1188", "email": "liam.nelson@outdoors.com",
            "items": [("Insulated Trail Thermos (1L)", 2, 36.00), ("Freeze-Dried Coffee Packs", 4, 9.50)],
            "discount": 0.0, "delivery": 5.00, "status": OrderStatus.DELIVERED,
            "pay_status": PaymentStatus.PAID, "pay_method": PaymentMethod.UPI,
            "age_days": 8, "delivered_days_after": 1.3, "notes": "Standard postal delivery."
        },
        {
            "id": "ORD-2026-1027", "name": "Hannah Abbott", "phone": "+44 1632 960123", "email": "hannah.abbott@botanics.uk",
            "items": [("Herbal Infusion Tea Sampler", 3, 16.50), ("Cast Iron Teapot (800ml)", 1, 58.00)],
            "discount": 10.0, "delivery": 6.50, "status": OrderStatus.PROCESSING,
            "pay_status": PaymentStatus.PAID, "pay_method": PaymentMethod.DEBIT_CARD,
            "age_days": 1.1, "delivered_days_after": None, "notes": "Handle with care."
        },
        {
            "id": "ORD-2026-1028", "name": "Oliver Twist", "phone": "+44 20 7946 0888", "email": "oliver.t@parish.org.uk",
            "items": [("Porridge Oats Bulk Bag (5kg)", 2, 14.00)],
            "discount": 0.0, "delivery": 3.00, "status": OrderStatus.PLACED,
            "pay_status": PaymentStatus.PENDING, "pay_method": PaymentMethod.CASH,
            "age_days": 0.2, "delivered_days_after": None, "notes": "Customer requested more."
        },
        {
            "id": "ORD-2026-1029", "name": "Siddharth Verma", "phone": "+91 94444-12345", "email": "siddharth.v@retail.in",
            "items": [("South Indian Filter Coffee Press", 2, 22.00), ("Chicory Coffee Blend (500g)", 4, 12.00)],
            "discount": 5.0, "delivery": 4.00, "status": OrderStatus.DELIVERED,
            "pay_status": PaymentStatus.PAID, "pay_method": PaymentMethod.UPI,
            "age_days": 5, "delivered_days_after": 1.0, "notes": "Delivered to apartment security."
        },
        {
            "id": "ORD-2026-1030", "name": "Nora Fatehi", "phone": "+1 555-1345", "email": "nora.f@studio.com",
            "items": [("Aromatherapy Electric Diffuser", 1, 65.00), ("Essential Oil 6-Pack", 2, 28.00)],
            "discount": 15.0, "delivery": 0.0, "status": OrderStatus.SHIPPED,
            "pay_status": PaymentStatus.PAID, "pay_method": PaymentMethod.CREDIT_CARD,
            "age_days": 1.8, "delivered_days_after": None, "notes": "Dispatched via standard courier."
        },
        {
            "id": "ORD-2026-1031", "name": "Fiona Gallagher", "phone": "+1 555-1422", "email": "fiona.g@southside.net",
            "items": [("Laundromat Cleaning Concentrate", 4, 18.50)],
            "discount": 0.0, "delivery": 5.50, "status": OrderStatus.CANCELLED,
            "pay_status": PaymentStatus.REFUNDED, "pay_method": PaymentMethod.DEBIT_CARD,
            "age_days": 15, "delivered_days_after": None, "notes": "Card dispute resolved; refunded."
        },
        {
            "id": "ORD-2026-1032", "name": "Leo Tolstoy", "phone": "+7 495 123 4567", "email": "leo.tolstoy@yasnaya.ru",
            "items": [("Fountain Pen Ink (Midnight Blue)", 4, 16.00), ("Parchment Writing Pad", 5, 12.50)],
            "discount": 10.0, "delivery": 9.00, "status": OrderStatus.DELIVERED,
            "pay_status": PaymentStatus.PAID, "pay_method": PaymentMethod.BANK_TRANSFER,
            "age_days": 13, "delivered_days_after": 2.2, "notes": "Literary archive shipment."
        },
        {
            "id": "ORD-2026-1033", "name": "Ada Lovelace", "phone": "+44 20 7888 9999", "email": "ada.lovelace@engines.co.uk",
            "items": [("Mechanical Gear Model Kit", 1, 115.00), ("Analytical Engine Schematic Print", 2, 35.00)],
            "discount": 0.0, "delivery": 0.0, "status": OrderStatus.DELIVERED,
            "pay_status": PaymentStatus.PAID, "pay_method": PaymentMethod.CREDIT_CARD,
            "age_days": 6, "delivered_days_after": 1.1, "notes": "First computer program celebration."
        },
        {
            "id": "ORD-2026-1034", "name": "Gabriel Garcia", "phone": "+57 1 234 5678", "email": "gabriel.garcia@macondo.co",
            "items": [("Colombian Geisha Whole Beans", 2, 45.00), ("Yellow Butterfly Ceramic Mug", 2, 19.00)],
            "discount": 8.0, "delivery": 7.00, "status": OrderStatus.PROCESSING,
            "pay_status": PaymentStatus.PAID, "pay_method": PaymentMethod.CREDIT_CARD,
            "age_days": 0.7, "delivered_days_after": None, "notes": "Gift message enclosed."
        },
        {
            "id": "ORD-2026-1035", "name": "Rachel Green", "phone": "+1 555-1555", "email": "rachel.green@ralphlauren.com",
            "items": [("Cashmere Travel Wrap", 1, 240.00), ("Leather Passport Wallet", 1, 65.00)],
            "discount": 20.0, "delivery": 12.00, "status": OrderStatus.DELIVERED,
            "pay_status": PaymentStatus.PAID, "pay_method": PaymentMethod.CREDIT_CARD,
            "age_days": 10, "delivered_days_after": 1.8, "notes": "Corporate express delivery."
        },
        {
            "id": "ORD-2026-1036", "name": "Monica Geller", "phone": "+1 555-1556", "email": "monica.chef@alessandros.com",
            "items": [("Professional Chef Knife (8in)", 1, 185.00), ("Microfiber Kitchen Cloth Set (12pk)", 3, 14.00)],
            "discount": 5.0, "delivery": 0.0, "status": OrderStatus.SHIPPED,
            "pay_status": PaymentStatus.PAID, "pay_method": PaymentMethod.DEBIT_CARD,
            "age_days": 1.3, "delivered_days_after": None, "notes": "Must be immaculately clean."
        },
        {
            "id": "ORD-2026-1037", "name": "Chandler Bing", "phone": "+1 555-1557", "email": "chandler.bing@wencode.com",
            "items": [("Ergonomic Lumbar Cushion", 1, 48.00), ("Blue Light Blocking Glasses", 1, 35.00)],
            "discount": 0.0, "delivery": 4.50, "status": OrderStatus.DELIVERED,
            "pay_status": PaymentStatus.PAID, "pay_method": PaymentMethod.CREDIT_CARD,
            "age_days": 9, "delivered_days_after": 1.2, "notes": "Could this BE any more comfortable?"
        },
        {
            "id": "ORD-2026-1038", "name": "Joey Tribbiani", "phone": "+1 555-1558", "email": "joey.t@actoragency.com",
            "items": [("Giant Meatball Marinara Pan (Frozen)", 3, 28.00), ("Garlic Bread Loaves (6pk)", 2, 12.00)],
            "discount": 0.0, "delivery": 8.00, "status": OrderStatus.PLACED,
            "pay_status": PaymentStatus.PENDING, "pay_method": PaymentMethod.CASH,
            "age_days": 0.1, "delivered_days_after": None, "notes": "Joey doesn't share food!"
        },
        {
            "id": "ORD-2026-1039", "name": "Phoebe Buffay", "phone": "+1 555-1559", "email": "phoebe.buffay@massage.org",
            "items": [("Smelly Cat Organic Catnip Pouch", 5, 8.00), ("Guitar Strap Bohemian Fabric", 1, 29.00)],
            "discount": 10.0, "delivery": 3.50, "status": OrderStatus.DELIVERED,
            "pay_status": PaymentStatus.PAID, "pay_method": PaymentMethod.CASH,
            "age_days": 11, "delivered_days_after": 1.5, "notes": "Eco-friendly compostable packaging."
        },
        {
            "id": "ORD-2026-1040", "name": "Ross Geller", "phone": "+1 555-1560", "email": "paleo.ross@nyumuseum.edu",
            "items": [("Fossil Excavation Brush Kit", 2, 34.00), ("T-Rex Dinosaur Desk Model", 1, 62.00)],
            "discount": 0.0, "delivery": 6.00, "status": OrderStatus.PROCESSING,
            "pay_status": PaymentStatus.PAID, "pay_method": PaymentMethod.CREDIT_CARD,
            "age_days": 0.9, "delivered_days_after": None, "notes": "PIVOT! Deliver through rear elevator."
        },
        {
            "id": "ORD-2026-1041", "name": "Sherlock Holmes", "phone": "+44 20 7221 9249", "email": "sherlock@221bbaker.co.uk",
            "items": [("Magnifying Glass (Doublet Achromat)", 1, 75.00), ("Violin Rosin & Strings Set", 1, 42.00)],
            "discount": 0.0, "delivery": 5.00, "status": OrderStatus.DELIVERED,
            "pay_status": PaymentStatus.PAID, "pay_method": PaymentMethod.BANK_TRANSFER,
            "age_days": 14, "delivered_days_after": 1.6, "notes": "The game is afoot."
        },
        {
            "id": "ORD-2026-1042", "name": "John H. Watson", "phone": "+44 20 7221 9250", "email": "dr.watson@medicalbaker.co.uk",
            "items": [("Leather Bound Medical Stethoscope Case", 1, 52.00), ("Fountain Pen Black Refills (10pk)", 2, 14.00)],
            "discount": 5.0, "delivery": 4.00, "status": OrderStatus.DELIVERED,
            "pay_status": PaymentStatus.PAID, "pay_method": PaymentMethod.DEBIT_CARD,
            "age_days": 13, "delivered_days_after": 1.3, "notes": "Delivered to Doctor Watson."
        },
    ]

    orders: list[Order] = []
    for item in orders_data:
        created_dt = now - timedelta(days=item["age_days"])
        created_iso = created_dt.isoformat()

        order_items = [OrderItem(name=n, quantity=q, unit_price=p) for n, q, p in item["items"]]

        # Build realistic status history
        history = [StatusHistoryEntry(status=OrderStatus.PLACED.value, timestamp=created_iso, note="Initial order placed.")]
        updated_iso = created_iso

        st = item["status"]
        if st in (OrderStatus.PROCESSING, OrderStatus.SHIPPED, OrderStatus.DELIVERED, OrderStatus.CANCELLED):
            proc_dt = created_dt + timedelta(hours=3)
            history.append(StatusHistoryEntry(status=OrderStatus.PROCESSING.value, timestamp=proc_dt.isoformat(), note="Payment verified and kitchen/inventory processing."))
            updated_iso = proc_dt.isoformat()

        if st in (OrderStatus.SHIPPED, OrderStatus.DELIVERED):
            ship_dt = created_dt + timedelta(hours=14)
            history.append(StatusHistoryEntry(status=OrderStatus.SHIPPED.value, timestamp=ship_dt.isoformat(), note="Handed over to carrier courier."))
            updated_iso = ship_dt.isoformat()

        if st == OrderStatus.DELIVERED:
            deliv_days = item["delivered_days_after"] or 1.5
            deliv_dt = created_dt + timedelta(days=deliv_days)
            history.append(StatusHistoryEntry(status=OrderStatus.DELIVERED.value, timestamp=deliv_dt.isoformat(), note="Delivered to customer."))
            updated_iso = deliv_dt.isoformat()

        if st == OrderStatus.CANCELLED:
            cancel_dt = created_dt + timedelta(hours=6)
            history.append(StatusHistoryEntry(status=OrderStatus.CANCELLED.value, timestamp=cancel_dt.isoformat(), note=item["notes"]))
            updated_iso = cancel_dt.isoformat()

        order = Order(
            order_id=item["id"],
            customer_name=item["name"],
            customer_phone=item["phone"],
            customer_email=item["email"],
            items=order_items,
            discount_pct=item["discount"],
            delivery_fee=item["delivery"],
            status=st,
            payment_status=item["pay_status"],
            payment_method=item["pay_method"],
            created_at=created_iso,
            updated_at=updated_iso,
            status_history=history,
            notes=item["notes"],
        )
        orders.append(order)

    # Save to sample_orders.json
    raw_sample = [o.to_dict() for o in orders]
    with open(SAMPLE_ORDERS_JSON_PATH, "w", encoding="utf-8") as f:
        json.dump(raw_sample, f, indent=2, ensure_ascii=False)

    # Initialize active database with these orders
    mgr = PersistenceManager(ORDERS_JSON_PATH, ORDERS_CSV_PATH)
    mgr.save_orders(orders)
    print(f"Generated {len(orders)} sample orders in {SAMPLE_ORDERS_JSON_PATH} and synced {ORDERS_JSON_PATH}.")

    # Generate legacy_import_sample.csv with intentional valid and invalid rows
    legacy_csv_rows = [
        "order_id,customer_name,phone,email,items,discount_pct,delivery_fee,status,payment_status,payment_method",
        # Valid Row 1
        "LEG-2026-9001,Lucas Vance,+1 555-8811,lucas.v@vancemail.com,Artisan Coffee Beans:2:16.50; Ceramic Mug:1:14.00,5.0,3.50,PLACED,PENDING,CASH",
        # Valid Row 2
        "LEG-2026-9002,Beatrix Potter,+44 1539 442233,beatrix@hilltop.co.uk,Cottage Garden Seed Kit:3:12.00,0.0,4.00,PROCESSING,PAID,CREDIT_CARD",
        # Valid Row 3
        "LEG-2026-9003,Samwise Gamgee,+1 555-4321,samwise@theshire.net,Elven Waybread Rations:5:8.50; Iron Cooking Pot:1:35.00,10.0,0.00,DELIVERED,PAID,UPI",
        # Invalid Row 4: Malformed Order ID
        "!!!BAD_ID!!!,Gregor Samsa,+1 555-9999,gregor@insects.de,Metamorphosis Coffee:1:15.00,0.0,2.00,PLACED,PENDING,CASH",
        # Invalid Row 5: Empty Customer Name
        "LEG-2026-9005,,+1 555-0000,anonymous@nowhere.com,Blank Notebook:1:10.00,0.0,0.00,PLACED,PENDING,CASH",
        # Invalid Row 6: Illegal Status string
        "LEG-2026-9006,Don Quixote,+34 91 123 4567,don.quixote@lamancha.es,Knight Errant Lance:1:120.00,0.0,15.00,FLYING_IN_SPACE,PAID,BANK_TRANSFER",
        # Valid Row 7
        "LEG-2026-9007,Elizabeth Bennet,+44 1632 960888,elizabeth.b@longbourn.org,Lace Handkerchief:2:18.00; Writing Quills:1:22.00,0.0,4.50,SHIPPED,PAID,DEBIT_CARD",
    ]

    with open(LEGACY_SAMPLE_CSV_PATH, "w", encoding="utf-8") as f:
        f.write("\n".join(legacy_csv_rows) + "\n")
    print(f"Generated legacy import sample CSV in {LEGACY_SAMPLE_CSV_PATH}.")


if __name__ == "__main__":
    generate_sample_data()
