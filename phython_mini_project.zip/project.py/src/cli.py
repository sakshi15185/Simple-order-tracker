"""
Interactive Terminal Console Interface
Delivers a menu-driven, crash-proof command prompt with ANSI color styling,
fixed-width paginated tables, breadcrumb navigation, and operational warning flags.
"""

import os
import sys
from typing import List, Optional
from datetime import datetime, timezone

from src.config import (
    OrderStatus,
    PaymentStatus,
    PaymentMethod,
    Colors,
    PAGE_SIZE,
    OVERDUE_HOURS_THRESHOLD,
    HIGH_VALUE_THRESHOLD,
)
from src.models import Order, OrderItem
from src.business_logic import OrderManager
from src.validator import (
    validate_order_id,
    validate_customer_name,
    validate_phone,
    validate_email,
    validate_item_name,
    validate_quantity,
    validate_unit_price,
    validate_discount_pct,
    validate_delivery_fee,
    validate_date_str,
    prompt_string,
    prompt_int,
    prompt_float,
    prompt_choice,
    prompt_confirm,
)
from src.analytics import OrderAnalytics
from src.exporter import ReportExporter
from src.bulk_importer import BulkImporter


def clear_screen():
    """Clears terminal screen across platforms."""
    os.system("cls" if os.name == "nt" else "clear")


class CommandLineInterface:
    """Orchestrates interactive terminal user journeys for Simple Order Tracker."""

    def __init__(self, manager: OrderManager):
        self.manager = manager

    def print_banner(self):
        """Displays branded hackathon header."""
        print(f"{Colors.CYAN}{Colors.BOLD}")
        print("================================================================================")
        print("       SIMPLE ORDER TRACKER | Small Business & Retail Operations                ")
        print("            SmartCommunity Hack #85 | High Reliability Engine                   ")
        print("================================================================================")
        print(f"{Colors.RESET}", end="")

    def print_alert_banner(self):
        """Displays high-priority warning flags above menu."""
        if self.manager.load_warnings:
            for w in self.manager.load_warnings:
                print(f"{Colors.YELLOW}[!] STORAGE NOTICE: {w}{Colors.RESET}")

        overdue = self.manager.get_overdue_orders()
        if overdue:
            print(f"{Colors.RED}{Colors.BOLD}[!] ALERT: {len(overdue)} order(s) overdue (exceeding {OVERDUE_HOURS_THRESHOLD}h SLA without shipment).{Colors.RESET}")
            print(f"{Colors.DIM}    -> Select option [6] to review overdue entries immediately.{Colors.RESET}")

    def run(self):
        """Main navigation dispatch loop."""
        while True:
            self.print_banner()
            self.print_alert_banner()
            print(f"\n{Colors.BOLD}Main Navigation Menu:{Colors.RESET}")
            print(f"  [{Colors.GREEN}1{Colors.RESET}] Record New Order (Defensive Interactive Form)")
            print(f"  [{Colors.GREEN}2{Colors.RESET}] View All Orders (Paginated Formatted Table)")
            print(f"  [{Colors.GREEN}3{Colors.RESET}] Search & Filter Orders (Keyword, Status, Date, Amount)")
            print(f"  [{Colors.GREEN}4{Colors.RESET}] Update Order Status (Guided State Machine Transition)")
            print(f"  [{Colors.GREEN}5{Colors.RESET}] Update Payment Status (Pending / Paid / Refunded)")
            print(f"  [{Colors.GREEN}6{Colors.RESET}] Operational Warnings & Overdue SLA Monitor")
            print(f"  [{Colors.GREEN}7{Colors.RESET}] Executive Summary & Business Analytics (KPIs & Trends)")
            print(f"  [{Colors.GREEN}8{Colors.RESET}] Export Reports & Visual Charts (Markdown, CSV, PNG)")
            print(f"  [{Colors.GREEN}9{Colors.RESET}] Bulk Import Legacy Orders (CSV Ingestion & Audit Log)")
            print(f"  [{Colors.GREEN}10{Colors.RESET}] Reset / Reload 42 Sample Records")
            print(f"  [{Colors.GREEN}11{Colors.RESET}] Launch Graphical User Interface (Tkinter GUI)")
            print(f"  [{Colors.RED}0{Colors.RESET}] Exit Application\n")

            choice = input(f"{Colors.BOLD}Select an option [0-11]: {Colors.RESET}").strip()

            if choice == "1":
                self.handle_record_new_order()
            elif choice == "2":
                self.handle_view_all_orders()
            elif choice == "3":
                self.handle_search_orders()
            elif choice == "4":
                self.handle_update_status()
            elif choice == "5":
                self.handle_update_payment()
            elif choice == "6":
                self.handle_warnings_monitor()
            elif choice == "7":
                self.handle_executive_summary()
            elif choice == "8":
                self.handle_export_reports()
            elif choice == "9":
                self.handle_bulk_import()
            elif choice == "10":
                self.handle_reload_sample_data()
            elif choice == "11":
                self.handle_launch_gui()
            elif choice in ("0", "q", "exit"):
                print(f"\n{Colors.GREEN}Thank you for using Simple Order Tracker. Goodbye!{Colors.RESET}\n")
                break
            else:
                print(f"{Colors.RED}[!] Invalid choice. Please enter a number between 0 and 11.{Colors.RESET}")
                input("Press [Enter] to continue...")

    # --- Menu Handlers ---

    def handle_record_new_order(self):
        """Guided, defensive order creation wizard."""
        print(f"\n{Colors.CYAN}{Colors.BOLD}--- Record New Order Wizard ---{Colors.RESET}")
        print(f"{Colors.DIM}Complete the guided prompts below. Enter ':q' at any step to abort.{Colors.RESET}\n")

        # 1. Order ID (suggest next sequential)
        next_id = self.manager.generate_next_order_id()
        order_id = prompt_string(f"Order ID (press Enter for auto-generated)", validate_order_id, default=next_id)
        if not order_id:
            return

        if self.manager.get_order(order_id):
            print(f"{Colors.RED}[!] Error: An order with ID '{order_id}' already exists!{Colors.RESET}")
            input("Press [Enter] to return...")
            return

        # 2. Customer Name
        cust_name = prompt_string("Customer Full Name", validate_customer_name)
        if not cust_name:
            return

        # 3. Customer Phone
        cust_phone = prompt_string("Customer Phone Number", validate_phone, default="+1 555-0100")
        if not cust_phone:
            return

        # 4. Customer Email
        cust_email = prompt_string("Customer Email Address", validate_email, default="customer@example.com")
        if not cust_email:
            return

        # 5. Order Line Items
        items: List[OrderItem] = []
        print(f"\n{Colors.YELLOW}--- Add Order Line Items ---{Colors.RESET}")
        while True:
            print(f"Adding Item #{len(items) + 1}:")
            item_name = prompt_string("  Item Description / Product Name", validate_item_name)
            if not item_name:
                if items:
                    print(f"{Colors.YELLOW}Finished adding line items.{Colors.RESET}")
                    break
                else:
                    print(f"{Colors.RED}[!] At least one item is required.{Colors.RESET}")
                    continue

            qty = prompt_int("  Quantity", min_val=1, max_val=10_000, default=1)
            if qty is None:
                if items:
                    break
                return

            price = prompt_float("  Unit Price ($)", min_val=0.01, max_val=100_000.0)
            if price is None:
                if items:
                    break
                return

            items.append(OrderItem(name=item_name, quantity=qty, unit_price=price))
            print(f"  {Colors.GREEN}✓ Added: {item_name} (x{qty} @ ${price:.2f} = ${qty * price:.2f}){Colors.RESET}")

            if not prompt_confirm("Add another item?", default=False):
                break

        # 6. Discount & Delivery
        print(f"\n{Colors.YELLOW}--- Pricing & Adjustments ---{Colors.RESET}")
        discount_pct = prompt_float("Discount Percentage (0 to 100%)", min_val=0.0, max_val=100.0, default=0.0)
        if discount_pct is None:
            discount_pct = 0.0

        delivery_fee = prompt_float("Delivery Fee ($)", min_val=0.0, max_val=10_000.0, default=0.0)
        if delivery_fee is None:
            delivery_fee = 0.0

        # 7. Payment Info
        pay_methods = [m.value for m in PaymentMethod]
        chosen_method = prompt_choice("Select Payment Method", pay_methods, default=PaymentMethod.CASH.value)
        if not chosen_method:
            chosen_method = PaymentMethod.CASH.value

        pay_statuses = [p.value for p in PaymentStatus]
        chosen_pay_status = prompt_choice("Select Payment Status", pay_statuses, default=PaymentStatus.PENDING.value)
        if not chosen_pay_status:
            chosen_pay_status = PaymentStatus.PENDING.value

        notes = prompt_string("Optional Notes / Instructions", default="", allow_cancel=False) or ""

        # Pre-calculation verification
        temp_order = Order(
            order_id=order_id,
            customer_name=cust_name,
            customer_phone=cust_phone,
            customer_email=cust_email,
            items=items,
            discount_pct=discount_pct,
            delivery_fee=delivery_fee,
            status=OrderStatus.PLACED,
            payment_status=PaymentStatus(chosen_pay_status),
            payment_method=PaymentMethod(chosen_method),
            notes=notes,
        )

        print(f"\n{Colors.CYAN}{Colors.BOLD}--- Order Confirmation Summary ---{Colors.RESET}")
        print(f"  Order ID:       {temp_order.order_id}")
        print(f"  Customer:       {temp_order.customer_name} ({temp_order.customer_phone})")
        print(f"  Items:          {temp_order.total_quantity} item(s)")
        print(f"  Subtotal:       ${temp_order.subtotal:.2f}")
        print(f"  Discount:       -${temp_order.discount_amount:.2f} ({temp_order.discount_pct}%)")
        print(f"  Tax (5%):       +${temp_order.tax_amount:.2f}")
        print(f"  Delivery Fee:   +${temp_order.delivery_fee:.2f}")
        print(f"  {Colors.BOLD}GRAND TOTAL:    ${temp_order.total_amount:.2f}{Colors.RESET}")
        print(f"  Status:         {temp_order.status.value}")
        print(f"  Payment:        {temp_order.payment_status.value} ({temp_order.payment_method.value})")

        if prompt_confirm("\nConfirm and record this order?", default=True):
            ok, msg = self.manager.create_order(temp_order)
            if ok:
                print(f"{Colors.GREEN}{Colors.BOLD}✓ SUCCESS: {msg}{Colors.RESET}")
            else:
                print(f"{Colors.RED}[!] Error: {msg}{Colors.RESET}")
        else:
            print(f"{Colors.YELLOW}Order discarded.{Colors.RESET}")

        input("\nPress [Enter] to continue...")

    def handle_view_all_orders(self):
        """Displays orders in a fixed-width, paginated ANSI table."""
        orders = self.manager.get_all_orders()
        self._display_paginated_orders(orders, title="All Active & Historic Orders")

    def handle_search_orders(self):
        """Interactive search and filter query builder."""
        print(f"\n{Colors.CYAN}{Colors.BOLD}--- Search & Filter Orders ---{Colors.RESET}")
        print(f"{Colors.DIM}Leave any filter blank to skip it.{Colors.RESET}\n")

        kw = input(f"{Colors.BOLD}Search Keyword (ID, Customer, Phone, Email, Product): {Colors.RESET}").strip()
        kw_param = kw if kw else None

        print(f"\nFilter by Order Status:")
        print("  [0] Any Status (Skip)")
        for idx, s in enumerate(OrderStatus, 1):
            print(f"  [{idx}] {s.value}")
        st_choice = input("Select [0-5]: ").strip()
        status_param = None
        if st_choice.isdigit() and 1 <= int(st_choice) <= len(OrderStatus):
            status_param = list(OrderStatus)[int(st_choice) - 1]

        print(f"\nFilter by Payment Status:")
        print("  [0] Any Payment Status (Skip)")
        for idx, p in enumerate(PaymentStatus, 1):
            print(f"  [{idx}] {p.value}")
        pay_choice = input("Select [0-3]: ").strip()
        pay_param = None
        if pay_choice.isdigit() and 1 <= int(pay_choice) <= len(PaymentStatus):
            pay_param = list(PaymentStatus)[int(pay_choice) - 1]

        min_amt_str = input(f"{Colors.BOLD}Minimum Total Amount ($) [Skip]: {Colors.RESET}").strip()
        min_amt = float(min_amt_str) if min_amt_str.replace(".", "", 1).isdigit() else None

        max_amt_str = input(f"{Colors.BOLD}Maximum Total Amount ($) [Skip]: {Colors.RESET}").strip()
        max_amt = float(max_amt_str) if max_amt_str.replace(".", "", 1).isdigit() else None

        print("\nSort Results By:")
        print("  [1] Date (Newest first)")
        print("  [2] Date (Oldest first)")
        print("  [3] Amount (Highest first)")
        print("  [4] Amount (Lowest first)")
        print("  [5] Order ID (Ascending)")
        sort_choice = input("Select [1-5, default 1]: ").strip()
        sort_map = {
            "1": "date_desc",
            "2": "date_asc",
            "3": "amount_desc",
            "4": "amount_asc",
            "5": "id_asc",
        }
        sort_by = sort_map.get(sort_choice, "date_desc")

        results = self.manager.search_orders(
            keyword=kw_param,
            status=status_param,
            payment_status=pay_param,
            min_amount=min_amt,
            max_amount=max_amt,
            sort_by=sort_by,
        )

        filter_desc = []
        if kw_param:
            filter_desc.append(f"Keyword='{kw_param}'")
        if status_param:
            filter_desc.append(f"Status={status_param.value}")
        if pay_param:
            filter_desc.append(f"Payment={pay_param.value}")
        if min_amt:
            filter_desc.append(f"Min=${min_amt:.2f}")
        if max_amt:
            filter_desc.append(f"Max=${max_amt:.2f}")

        title = f"Search Results ({', '.join(filter_desc) if filter_desc else 'All Orders'})"
        self._display_paginated_orders(results, title=title)

    def _display_paginated_orders(self, orders: List[Order], title: str = "Orders"):
        """Renders paginated table with ANSI colors, fixed column widths, and detail drill-down."""
        if not orders:
            print(f"\n{Colors.YELLOW}[i] No matching orders found.{Colors.RESET}")
            input("Press [Enter] to return...")
            return

        total_records = len(orders)
        total_pages = (total_records + PAGE_SIZE - 1) // PAGE_SIZE
        current_page = 1

        while True:
            start_idx = (current_page - 1) * PAGE_SIZE
            end_idx = min(start_idx + PAGE_SIZE, total_records)
            page_slice = orders[start_idx:end_idx]

            print(f"\n{Colors.CYAN}{Colors.BOLD}=== {title} (Page {current_page}/{total_pages} | {total_records} Records) ==={Colors.RESET}")
            header = f"{'#':<3} | {'Order ID':<14} | {'Customer Name':<18} | {'Total ($)':<10} | {'Status':<12} | {'Payment':<9} | {'Date (UTC)':<11}"
            print("-" * len(header))
            print(f"{Colors.BOLD}{header}{Colors.RESET}")
            print("-" * len(header))

            for idx, o in enumerate(page_slice, start=start_idx + 1):
                # Status color formatting
                color = Colors.STATUS_COLORS.get(o.status.value, Colors.RESET)
                status_str = f"{color}{o.status.value:<12}{Colors.RESET}"
                # Alert icon if overdue
                overdue_flag = f"{Colors.RED}*!*{Colors.RESET}" if o.is_overdue() else "   "
                date_short = o.created_at[:10]
                cust_trunc = o.customer_name[:17]
                print(f"{idx:<3} | {o.order_id:<14} | {cust_trunc:<18} | ${o.total_amount:>8.2f} | {status_str} | {o.payment_status.value:<9} | {date_short:<11}")

            print("-" * len(header))
            print(f"{Colors.DIM}Commands: [N]ext | [P]rev | [V <#>] View Details | [U <#>] Update Status | [M]ain Menu{Colors.RESET}")

            cmd = input(f"{Colors.BOLD}Action: {Colors.RESET}").strip().lower()

            if cmd == "n":
                if current_page < total_pages:
                    current_page += 1
                else:
                    print(f"{Colors.YELLOW}Already on the last page.{Colors.RESET}")
            elif cmd == "p":
                if current_page > 1:
                    current_page -= 1
                else:
                    print(f"{Colors.YELLOW}Already on the first page.{Colors.RESET}")
            elif cmd.startswith("v"):
                # View details
                parts = cmd.split()
                if len(parts) > 1 and parts[1].isdigit():
                    rec_idx = int(parts[1]) - 1
                    if 0 <= rec_idx < total_records:
                        self._render_order_details(orders[rec_idx])
                    else:
                        print(f"{Colors.RED}[!] Record index out of range.{Colors.RESET}")
                else:
                    target_id = input("Enter Order ID to inspect: ").strip().upper()
                    target_ord = self.manager.get_order(target_id)
                    if target_ord:
                        self._render_order_details(target_ord)
                    else:
                        print(f"{Colors.RED}[!] Order ID not found.{Colors.RESET}")
            elif cmd.startswith("u"):
                parts = cmd.split()
                if len(parts) > 1 and parts[1].isdigit():
                    rec_idx = int(parts[1]) - 1
                    if 0 <= rec_idx < total_records:
                        self._guided_status_update(orders[rec_idx])
                    else:
                        print(f"{Colors.RED}[!] Record index out of range.{Colors.RESET}")
                else:
                    target_id = input("Enter Order ID to update: ").strip().upper()
                    target_ord = self.manager.get_order(target_id)
                    if target_ord:
                        self._guided_status_update(target_ord)
                    else:
                        print(f"{Colors.RED}[!] Order ID not found.{Colors.RESET}")
            elif cmd in ("m", "q", "exit", ""):
                break
            else:
                print(f"{Colors.RED}[!] Unrecognized command.{Colors.RESET}")

    def _render_order_details(self, order: Order):
        """Displays full itemized receipt, financial breakdown, and status timeline."""
        status_color = Colors.STATUS_COLORS.get(order.status.value, Colors.WHITE)
        print(f"\n{Colors.CYAN}{Colors.BOLD}================================================================{Colors.RESET}")
        print(f"  {Colors.BOLD}ORDER DETAILS: {order.order_id}{Colors.RESET}")
        print(f"{Colors.CYAN}================================================================{Colors.RESET}")
        print(f"  Customer:        {order.customer_name}")
        print(f"  Phone:           {order.customer_phone}")
        print(f"  Email:           {order.customer_email}")
        print(f"  Current Status:  {status_color}{Colors.BOLD}{order.status.value}{Colors.RESET}")
        print(f"  Payment Status:  {order.payment_status.value} (Method: {order.payment_method.value})")
        print(f"  Created At:      {order.created_at[:19].replace('T', ' ')} UTC")
        print(f"  Last Updated:    {order.updated_at[:19].replace('T', ' ')} UTC")

        if order.is_overdue():
            print(f"  {Colors.RED}{Colors.BOLD}[!] SLA WARNING: Order is OVERDUE (>48h pending without shipment){Colors.RESET}")
        if order.total_amount >= HIGH_VALUE_THRESHOLD:
            print(f"  {Colors.YELLOW}{Colors.BOLD}[*] HIGH VALUE: Order exceeds ${HIGH_VALUE_THRESHOLD:.2f} threshold{Colors.RESET}")

        print(f"\n  {Colors.BOLD}Line Items Breakdown:{Colors.RESET}")
        print(f"  {'#':<3} | {'Product Name':<35} | {'Qty':<5} | {'Unit ($)':<10} | {'Subtotal ($)':<12}")
        print("  " + "-" * 70)
        for idx, it in enumerate(order.items, 1):
            print(f"  {idx:<3} | {it.name[:35]:<35} | {it.quantity:<5} | ${it.unit_price:>8.2f} | ${it.subtotal:>10.2f}")
        print("  " + "-" * 70)

        print(f"  Subtotal:             ${order.subtotal:>10.2f}")
        print(f"  Discount ({order.discount_pct:>4.1f}%):       -${order.discount_amount:>10.2f}")
        print(f"  Taxable Amount:       ${order.taxable_amount:>10.2f}")
        print(f"  Tax (5.0%):           +${order.tax_amount:>10.2f}")
        print(f"  Delivery Fee:         +${order.delivery_fee:>10.2f}")
        print(f"  {Colors.BOLD}GRAND TOTAL:          ${order.total_amount:>10.2f}{Colors.RESET}")

        if order.notes:
            print(f"\n  Notes: {order.notes}")

        print(f"\n  {Colors.BOLD}Lifecycle Audit Trail & State Transitions:{Colors.RESET}")
        for idx, h in enumerate(order.status_history, 1):
            ts = h.timestamp[:19].replace("T", " ")
            print(f"    {idx}. [{ts}] -> {h.status:<11} | {h.note}")

        print(f"{Colors.CYAN}================================================================{Colors.RESET}")
        input("Press [Enter] to return...")

    def handle_update_status(self):
        """Interactive workflow step to transition order status according to finite state rules."""
        print(f"\n{Colors.CYAN}{Colors.BOLD}--- Update Order Status ---{Colors.RESET}")
        order_id = input(f"{Colors.BOLD}Enter Order ID to update: {Colors.RESET}").strip().upper()
        order = self.manager.get_order(order_id)
        if not order:
            print(f"{Colors.RED}[!] Order '{order_id}' not found.{Colors.RESET}")
            input("Press [Enter] to return...")
            return

        self._guided_status_update(order)

    def _guided_status_update(self, order: Order):
        """Guided transition enforcing ALLOWED_TRANSITIONS."""
        print(f"\nOrder: {Colors.BOLD}{order.order_id}{Colors.RESET} | Customer: {order.customer_name}")
        cur_color = Colors.STATUS_COLORS.get(order.status.value, Colors.WHITE)
        print(f"Current Status: {cur_color}{Colors.BOLD}{order.status.value}{Colors.RESET}")

        from src.config import ALLOWED_TRANSITIONS
        allowed = ALLOWED_TRANSITIONS.get(order.status, [])

        if not allowed:
            print(f"{Colors.YELLOW}[i] Order is in terminal state '{order.status.value}'. No further transitions permitted.{Colors.RESET}")
            input("Press [Enter] to continue...")
            return

        print(f"\n{Colors.BOLD}Allowed Next Transitions:{Colors.RESET}")
        for idx, target in enumerate(allowed, 1):
            t_color = Colors.STATUS_COLORS.get(target.value, Colors.WHITE)
            print(f"  [{idx}] Transition to: {t_color}{Colors.BOLD}{target.value}{Colors.RESET}")
        print(f"  [0] Cancel / Keep Current Status")

        sel = input(f"{Colors.BOLD}Select target status [1-{len(allowed)} or 0]: {Colors.RESET}").strip()
        if sel == "0" or not sel.isdigit():
            print(f"{Colors.YELLOW}Status transition aborted.{Colors.RESET}")
            return

        idx = int(sel)
        if not (1 <= idx <= len(allowed)):
            print(f"{Colors.RED}[!] Invalid option selection.{Colors.RESET}")
            return

        target_status = allowed[idx - 1]
        note = input(f"{Colors.BOLD}Enter transition note / audit comment: {Colors.RESET}").strip()

        ok, msg = self.manager.update_order_status(order.order_id, target_status, note=note)
        if ok:
            print(f"{Colors.GREEN}{Colors.BOLD}✓ SUCCESS: {msg}{Colors.RESET}")
        else:
            print(f"{Colors.RED}[!] Failed: {msg}{Colors.RESET}")

        input("Press [Enter] to continue...")

    def handle_update_payment(self):
        """Updates payment status of an order."""
        print(f"\n{Colors.CYAN}{Colors.BOLD}--- Update Payment Status ---{Colors.RESET}")
        order_id = input(f"{Colors.BOLD}Enter Order ID: {Colors.RESET}").strip().upper()
        order = self.manager.get_order(order_id)
        if not order:
            print(f"{Colors.RED}[!] Order '{order_id}' not found.{Colors.RESET}")
            input("Press [Enter] to return...")
            return

        print(f"Order: {order.order_id} | Customer: {order.customer_name} | Total: ${order.total_amount:.2f}")
        print(f"Current Payment Status: {Colors.BOLD}{order.payment_status.value}{Colors.RESET} (Method: {order.payment_method.value})")

        statuses = [p.value for p in PaymentStatus]
        new_status_str = prompt_choice("Select New Payment Status", statuses, default=order.payment_status.value)
        if not new_status_str:
            return

        new_status = PaymentStatus(new_status_str)
        if new_status == order.payment_status:
            print(f"{Colors.YELLOW}No change in payment status.{Colors.RESET}")
            return

        note = input("Enter optional note: ").strip()
        ok, msg = self.manager.update_payment_status(order.order_id, new_status, note=note)
        if ok:
            print(f"{Colors.GREEN}{Colors.BOLD}✓ SUCCESS: {msg}{Colors.RESET}")
        else:
            print(f"{Colors.RED}[!] Error: {msg}{Colors.RESET}")

        input("Press [Enter] to continue...")

    def handle_warnings_monitor(self):
        """Displays threshold warning indicators and SLA deadline violations."""
        print(f"\n{Colors.RED}{Colors.BOLD}================================================================{Colors.RESET}")
        print(f"      {Colors.BOLD}OPERATIONAL THRESHOLD WARNINGS & OVERDUE SLA MONITOR{Colors.RESET}")
        print(f"{Colors.RED}================================================================{Colors.RESET}")

        overdue_orders = self.manager.get_overdue_orders()
        high_val_orders = self.manager.get_high_value_orders()

        # 1. Overdue SLA
        if overdue_orders:
            print(f"\n{Colors.RED}{Colors.BOLD}[!] {len(overdue_orders)} OVERDUE ORDERS DETECTED (Exceeding {OVERDUE_HOURS_THRESHOLD}h Turnaround Limit):{Colors.RESET}")
            print(f"{'Order ID':<14} | {'Customer':<18} | {'Status':<12} | {'Created At (UTC)':<19} | {'Total ($)':<10}")
            print("-" * 80)
            for o in overdue_orders:
                print(f"{o.order_id:<14} | {o.customer_name[:18]:<18} | {o.status.value:<12} | {o.created_at[:19]} | ${o.total_amount:>8.2f}")
            print("-" * 80)
            print(f"{Colors.YELLOW}Action Recommended: Prioritize dispatch or contact customer immediately.{Colors.RESET}")
        else:
            print(f"\n{Colors.GREEN}✓ No overdue orders! All active orders are within the {OVERDUE_HOURS_THRESHOLD}h SLA window.{Colors.RESET}")

        # 2. High-Value Alert
        if high_val_orders:
            print(f"\n{Colors.YELLOW}{Colors.BOLD}[*] {len(high_val_orders)} HIGH-VALUE ORDERS (Total >= ${HIGH_VALUE_THRESHOLD:.2f}):{Colors.RESET}")
            print(f"{'Order ID':<14} | {'Customer':<18} | {'Status':<12} | {'Payment':<9} | {'Total ($)':<10}")
            print("-" * 75)
            for o in high_val_orders:
                print(f"{o.order_id:<14} | {o.customer_name[:18]:<18} | {o.status.value:<12} | {o.payment_status.value:<9} | ${o.total_amount:>8.2f}")
            print("-" * 75)

        # 3. Unpaid Delivered / Shipped Alert
        unpaid_dispatched = [o for o in self.manager.get_all_orders() if o.status in (OrderStatus.SHIPPED, OrderStatus.DELIVERED) and o.payment_status == PaymentStatus.PENDING]
        if unpaid_dispatched:
            print(f"\n{Colors.RED}{Colors.BOLD}[!] {len(unpaid_dispatched)} DISPATCHED/DELIVERED ORDERS WITH PENDING PAYMENT:{Colors.RESET}")
            for o in unpaid_dispatched:
                print(f"    - {o.order_id}: {o.customer_name} (${o.total_amount:.2f}) -> Collect payment!")

        input("\nPress [Enter] to return...")

    def handle_executive_summary(self):
        """Displays comprehensive executive analytics dashboard."""
        analytics = OrderAnalytics(self.manager.get_all_orders())
        kpis = analytics.get_summary_kpis()
        status_df = analytics.get_status_distribution()
        top_prods = analytics.get_top_products(5)
        top_custs = analytics.get_top_customers(5)
        avg_sla = analytics.get_average_turnaround_time_hours()

        print(f"\n{Colors.CYAN}{Colors.BOLD}================================================================================")
        print("                 EXECUTIVE BUSINESS SUMMARY & ANALYTICS DASHBOARD               ")
        print(f"================================================================================{Colors.RESET}")

        # KPI Cards
        comp_str = f"{kpis['completion_rate_pct']}%"
        sla_str = f"{avg_sla}h" if avg_sla else "N/A"
        print(f"\n{Colors.BOLD}1. CORE BUSINESS METRICS:{Colors.RESET}")
        print(f"  +-------------------------------------+-------------------------------------+")
        print(f"  | Total Orders Logged:    {kpis['total_orders']:<11} | Total Gross Revenue:   ${kpis['total_revenue']:<10,.2f} |")
        print(f"  | Paid Revenue:          ${kpis['paid_revenue']:<11,.2f} | Pending Receivables:   ${kpis['pending_revenue']:<10,.2f} |")
        print(f"  | Average Order Value:   ${kpis['avg_order_value']:<11,.2f} | Total Units Sold:      {kpis['total_items_sold']:<10} |")
        print(f"  | Discounts Given:       ${kpis['total_discounts']:<11,.2f} | Total Tax (5%):        ${kpis['total_tax']:<10,.2f} |")
        print(f"  | Completion Rate:        {comp_str:<11} | Mean SLA Delivery:     {sla_str:<10} |")
        print(f"  +-------------------------------------+-------------------------------------+")

        # Status Table
        print(f"\n{Colors.BOLD}2. FULFILLMENT STATUS BREAKDOWN:{Colors.RESET}")
        print(f"  {'Status':<14} | {'Count':<6} | {'Share (%)':<10} | {'Revenue ($)':<14}")
        print("  " + "-" * 50)
        for _, r in status_df.iterrows():
            col = Colors.STATUS_COLORS.get(r["Status"], Colors.WHITE)
            print(f"  {col}{r['Status']:<14}{Colors.RESET} | {int(r['Count']):<6} | {r['Share (%)']:>7.1f}%   | ${r['Revenue ($)']:>12,.2f}")
        print("  " + "-" * 50)

        # Top Products
        print(f"\n{Colors.BOLD}3. TOP 5 BEST-SELLING PRODUCTS:{Colors.RESET}")
        if top_prods.empty:
            print("  No product sales data recorded.")
        else:
            print(f"  {'Product Description':<40} | {'Units':<6} | {'Total Revenue ($)':<16}")
            print("  " + "-" * 68)
            for _, r in top_prods.iterrows():
                print(f"  {r['Product'][:40]:<40} | {int(r['Qty Sold']):<6} | ${r['Total Revenue ($)']:>14,.2f}")
            print("  " + "-" * 68)

        # Top Customers
        print(f"\n{Colors.BOLD}4. TOP 5 CUSTOMERS BY SPEND:{Colors.RESET}")
        if top_custs.empty:
            print("  No customer data recorded.")
        else:
            print(f"  {'Customer Name':<30} | {'Orders':<8} | {'Total Spent ($)':<16}")
            print("  " + "-" * 60)
            for _, r in top_custs.iterrows():
                print(f"  {r['Customer'][:30]:<30} | {int(r['Orders']):<8} | ${r['Total Spent ($)']:>14,.2f}")
            print("  " + "-" * 60)

        input("\nPress [Enter] to return...")

    def handle_export_reports(self):
        """Exports reports to Markdown, CSV, plain-text audit, and Matplotlib chart."""
        print(f"\n{Colors.CYAN}{Colors.BOLD}--- Export Reports & Analytics Charts ---{Colors.RESET}")
        analytics = OrderAnalytics(self.manager.get_all_orders())
        exporter = ReportExporter(analytics)

        print("Generating multi-format exports...")

        # 1. Markdown
        md_path = exporter.export_markdown_report()
        print(f"  {Colors.GREEN}✓ Markdown Executive Report:{Colors.RESET} {md_path}")

        # 2. CSV Exports
        sum_csv, ord_csv = exporter.export_csv_reports()
        print(f"  {Colors.GREEN}✓ Sales Summary CSV:{Colors.RESET}         {sum_csv}")
        print(f"  {Colors.GREEN}✓ Full Orders Export CSV:{Colors.RESET}    {ord_csv}")

        # 3. Matplotlib Visual Chart
        chart_path = exporter.export_chart()
        if chart_path:
            print(f"  {Colors.GREEN}✓ Matplotlib Analytics Chart:{Colors.RESET} {chart_path}")
        else:
            print(f"  {Colors.YELLOW}[!] Chart generation skipped (no orders).{Colors.RESET}")

        print(f"\n{Colors.BOLD}All reports have been successfully generated in the 'reports/' folder!{Colors.RESET}")
        input("Press [Enter] to continue...")

    def handle_bulk_import(self):
        """Imports legacy orders from CSV file with error auditing."""
        print(f"\n{Colors.CYAN}{Colors.BOLD}--- Bulk Ingest Legacy Orders (CSV) ---{Colors.RESET}")
        from src.config import LEGACY_SAMPLE_CSV_PATH
        print(f"Default sample legacy CSV available at: {Colors.DIM}{LEGACY_SAMPLE_CSV_PATH}{Colors.RESET}")
        file_path_str = prompt_string("Enter CSV file path (press Enter for sample)", default=str(LEGACY_SAMPLE_CSV_PATH))
        if not file_path_str:
            return

        import_path = os.path.abspath(file_path_str)
        print(f"\nIngesting and validating records from {import_path}...")
        result = BulkImporter.import_csv(import_path)

        print(f"\n{Colors.BOLD}=== Bulk Import Results ==={Colors.RESET}")
        print(f"  Total Rows Scanned:   {result.total_rows}")
        print(f"  {Colors.GREEN}Successfully Parsed:  {result.successful_count}{Colors.RESET}")
        print(f"  {Colors.RED}Validation Failures:  {result.error_count}{Colors.RESET}")

        if result.errors:
            print(f"\n{Colors.YELLOW}Validation Error Log Highlights:{Colors.RESET}")
            for err in result.errors[:5]:
                print(f"  - {err}")
            if len(result.errors) > 5:
                print(f"  ...and {len(result.errors) - 5} more entries. See full audit log at:")
            print(f"  Full Error Log saved to: {Colors.CYAN}{result.log_file}{Colors.RESET}")

        if result.imported_orders:
            if prompt_confirm(f"\nCommit {len(result.imported_orders)} valid orders into the active tracker database?", default=True):
                added_count = 0
                duplicate_count = 0
                for o in result.imported_orders:
                    ok, _ = self.manager.create_order(o)
                    if ok:
                        added_count += 1
                    else:
                        duplicate_count += 1
                print(f"{Colors.GREEN}✓ Committed {added_count} orders successfully! ({duplicate_count} skipped duplicates){Colors.RESET}")
            else:
                print(f"{Colors.YELLOW}Import cancelled. No records committed.{Colors.RESET}")

        input("\nPress [Enter] to continue...")

    def handle_reload_sample_data(self):
        """Reloads the 42 realistic pre-seeded records."""
        if prompt_confirm("Are you sure you want to reset and reload the 42 sample records?", default=False):
            from src.seed_data import generate_sample_data
            generate_sample_data()
            self.manager.reload()
            print(f"{Colors.GREEN}✓ Successfully restored 42 sample records into the active database!{Colors.RESET}")
        else:
            print("Operation aborted.")
        input("Press [Enter] to continue...")

    def handle_launch_gui(self):
        """Launches the Tkinter Graphical User Interface."""
        print(f"\n{Colors.CYAN}Launching Tkinter GUI window...{Colors.RESET}")
        try:
            from src.gui import launch_gui
            launch_gui(self.manager)
        except Exception as e:
            print(f"{Colors.RED}[!] Could not launch GUI: {e}{Colors.RESET}")
            input("Press [Enter] to continue...")
